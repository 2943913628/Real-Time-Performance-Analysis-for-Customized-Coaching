#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src RS --seed 0 --tag hpo_RS > ../results/logs/hposrc_RS_s0.log 2>&1
