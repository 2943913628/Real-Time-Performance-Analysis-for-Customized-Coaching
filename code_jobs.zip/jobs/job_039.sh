#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src GWO --seed 0 --tag hpo_GWO > ../results/logs/hposrc_GWO_s0.log 2>&1
