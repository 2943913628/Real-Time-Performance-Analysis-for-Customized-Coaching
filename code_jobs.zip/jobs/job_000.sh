#!/bin/bash
cd /home/claude/EI0519-2/code
python3 hpo.py CLEAR_GWO 24 > ../results/logs/hpo_CLEAR_GWO.log 2>&1
