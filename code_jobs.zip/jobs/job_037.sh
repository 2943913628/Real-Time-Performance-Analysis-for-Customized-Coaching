#!/bin/bash
cd /home/claude/EI0519-2/code
python3 classical.py 0 > ../results/logs/classical_s0.log 2>&1
