#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src CLEAR_GWO --seed 0 --tag loso_TrackSprint --setting loso:TrackSprint > ../results/logs/loso_SPRINT_TrackSprint.log 2>&1
