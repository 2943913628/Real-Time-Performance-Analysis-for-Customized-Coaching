#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_exp.py --model Transformer --seed 0 --tag main --epochs 30 --patience 6 --robust 1 --save 1 > ../results/logs/main_Transformer_s0.log 2>&1
