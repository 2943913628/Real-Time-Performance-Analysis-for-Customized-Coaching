#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_exp.py --model TCN --seed 0 --tag cold --setting coldstart --epochs 30 --patience 6 > ../results/logs/cold_TCN.log 2>&1
