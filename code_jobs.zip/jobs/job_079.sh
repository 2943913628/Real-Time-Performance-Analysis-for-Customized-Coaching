#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_exp.py --model TCN --seed 0 --tag loso_Volleyball --setting loso:Volleyball --epochs 30 --patience 6 > ../results/logs/loso_TCN_Volleyball.log 2>&1
