#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src CLEAR_GWO --seed 0 --tag loso_Volleyball --setting loso:Volleyball > ../results/logs/loso_SPRINT_Volleyball.log 2>&1
