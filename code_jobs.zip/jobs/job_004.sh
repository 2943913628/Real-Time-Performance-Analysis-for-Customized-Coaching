#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src CLEAR_GWO --seed 0 --tag main --robust 1 --save 1 > ../results/logs/main_SPRINT_s0.log 2>&1
