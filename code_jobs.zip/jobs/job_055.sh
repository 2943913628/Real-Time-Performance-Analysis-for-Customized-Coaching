#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src CLEAR_GWO --seed 1 --tag abl_TAG_prior_only --flags '{"adaptive": 0, "dynamic": 0}' > ../results/logs/abl_TAG_prior_only_s1.log 2>&1
