#!/bin/bash
cd /home/claude/EI0519-2/code
python3 hpo.py GWO 24 > ../results/logs/hpo_GWO.log 2>&1
