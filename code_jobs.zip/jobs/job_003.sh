#!/bin/bash
cd /home/claude/EI0519-2/code
python3 hpo.py RS 24 > ../results/logs/hpo_RS.log 2>&1
