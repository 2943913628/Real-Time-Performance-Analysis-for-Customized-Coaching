#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src CLEAR_GWO --seed 1 --tag abl_noMSGTA --flags '{"msgta": false}' > ../results/logs/abl_noMSGTA_s1.log 2>&1
