#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src CLEAR_GWO --seed 0 --tag loso_Basketball --setting loso:Basketball > ../results/logs/loso_SPRINT_Basketball.log 2>&1
