#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src CLEAR_GWO --seed 0 --tag cold --setting coldstart > ../results/logs/cold_SPRINT.log 2>&1
