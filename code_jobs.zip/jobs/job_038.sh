#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src default --seed 0 --tag hpo_default > ../results/logs/hposrc_default_s0.log 2>&1
