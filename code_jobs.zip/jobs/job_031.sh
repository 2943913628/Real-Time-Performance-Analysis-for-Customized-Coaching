#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_exp.py --model MLP --seed 1 --tag TARNet --epochs 30 --patience 6 --save 1 --cfg '{"cim_head": true, "lam_p": 0.0, "flags": {"cf": false}}' > ../results/logs/TARNet_s1.log 2>&1
