#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src CLEAR_GWO --seed 0 --tag abl_noTAG --flags '{"graph": false}' > ../results/logs/abl_noTAG_s0.log 2>&1
