#!/bin/bash
cd /home/claude/EI0519-2/code
python3 hpo.py PSO 24 > ../results/logs/hpo_PSO.log 2>&1
