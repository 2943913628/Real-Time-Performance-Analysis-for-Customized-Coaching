#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src CLEAR_GWO --seed 0 --tag abl_noAug --flags '{"augment": false}' > ../results/logs/abl_noAug_s0.log 2>&1
