#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_exp.py --model MLP --seed 0 --tag DragonNet --epochs 30 --patience 6 --save 1 --cfg '{"cim_head": true, "lam_p": 1.0}' > ../results/logs/DragonNet_s0.log 2>&1
