#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src PSO --seed 0 --tag hpo_PSO > ../results/logs/hposrc_PSO_s0.log 2>&1
