#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_exp.py --model TCN --seed 0 --tag loso_Basketball --setting loso:Basketball --epochs 30 --patience 6 > ../results/logs/loso_TCN_Basketball.log 2>&1
