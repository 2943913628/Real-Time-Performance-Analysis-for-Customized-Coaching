#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_exp.py --model GraphWaveNet --seed 2 --tag main --epochs 30 --patience 6 --robust 0 --save 1 > ../results/logs/main_GraphWaveNet_s2.log 2>&1
