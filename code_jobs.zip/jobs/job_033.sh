#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_exp.py --model MLP --seed 1 --tag MLPaug --epochs 30 --patience 6 --save 1 --robust 0 --cfg '{"augment": true}' > ../results/logs/MLPaug_s1.log 2>&1
