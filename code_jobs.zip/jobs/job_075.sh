#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_exp.py --model MLP --seed 0 --tag loso_TrackSprint --setting loso:TrackSprint --epochs 30 --patience 6 > ../results/logs/loso_MLP_TrackSprint.log 2>&1
