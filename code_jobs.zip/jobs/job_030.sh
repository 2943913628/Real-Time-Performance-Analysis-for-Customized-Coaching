#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_exp.py --model MLP --seed 0 --tag MLPaug --epochs 30 --patience 6 --save 1 --robust 1 --cfg '{"augment": true}' > ../results/logs/MLPaug_s0.log 2>&1
