#!/bin/bash
cd /home/claude/EI0519-2/code
python3 run_sprint.py --src CLEAR_GWO --seed 1 --tag abl_noPCGA --flags '{"peer": false}' > ../results/logs/abl_noPCGA_s1.log 2>&1
