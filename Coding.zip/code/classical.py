"""classical.py -- classical ML and meta-learner baselines (scikit-learn) on hand-crafted window features."""
import numpy as np, json, os, sys, time
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.svm import SVC, SVR
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, HistGradientBoostingClassifier, HistGradientBoostingRegressor
from data import Dataset
import train as T

K = 5
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results", "runs")
os.makedirs(OUT, exist_ok=True)


def onehot(a):
    return np.eye(K)[a]


def s_learner(reg, Xtr, atr, qtr, Xte):
    reg.fit(np.hstack([Xtr, onehot(atr)]), qtr)
    return np.stack([reg.predict(np.hstack([Xte, onehot(np.full(len(Xte), k))])) for k in range(K)], 1)


def t_learner(make, Xtr, atr, qtr, Xte):
    mu = []
    for k in range(K):
        m = make(); m.fit(Xtr[atr == k], qtr[atr == k]); mu.append(m.predict(Xte))
    return np.stack(mu, 1)


def run(seed=0):
    D = Dataset()
    tr, te = D.split["train"], D.split["test"]
    Xtr, Xte = D.handcrafted(tr), D.handcrafted(te)
    ytr, ptr = D.y[tr].ravel(), D.pri[tr].ravel()
    atr, qtr = D.a[tr].ravel(), D.q[tr].ravel()
    w = D.class_w[ytr]
    fams = {
        "LR": (lambda: LogisticRegression(max_iter=2000, C=1.0, class_weight="balanced"),
               lambda: Ridge(alpha=1.0), "S", lambda: Ridge(alpha=1.0)),
        "SVM": (lambda: SVC(C=3.0, gamma="scale", probability=True, class_weight="balanced", random_state=seed),
                lambda: SVR(C=10.0, epsilon=1.0), "S", lambda: SVR(C=10.0, epsilon=0.5)),
        "RF": (lambda: RandomForestClassifier(400, min_samples_leaf=2, class_weight="balanced", n_jobs=1, random_state=seed),
               lambda: RandomForestRegressor(300, min_samples_leaf=3, n_jobs=1, random_state=seed), "T",
               lambda: RandomForestRegressor(200, min_samples_leaf=5, n_jobs=1, random_state=seed)),
        "HGB": (lambda: HistGradientBoostingClassifier(max_iter=400, learning_rate=0.06, class_weight="balanced", random_state=seed),
                lambda: HistGradientBoostingRegressor(max_iter=400, learning_rate=0.06, random_state=seed), "S",
                lambda: HistGradientBoostingRegressor(max_iter=400, learning_rate=0.06, random_state=seed)),
    }
    res = {}
    for name, (mc, mr, meta, mq) in fams.items():
        t0 = time.time()
        if name == "SVM":                       # SVM: subsample for tractability
            sub = np.random.default_rng(seed).choice(len(Xtr), 6000, replace=False)
        else:
            sub = np.arange(len(Xtr))
        c = mc(); c.fit(Xtr[sub], ytr[sub])
        r = mr(); r.fit(Xtr[sub], ptr[sub])
        if meta == "S":
            qm = mq(); qm.fit(np.hstack([Xtr[sub], onehot(atr[sub])]), qtr[sub])
            s_learner_pred = lambda Xf, qm=qm: np.stack([qm.predict(np.hstack([Xf, onehot(np.full(len(Xf), k))])) for k in range(K)], 1)
            mu = s_learner_pred(Xte)
        else:
            qms = []
            for k in range(K):
                mk = mq(); mk.fit(Xtr[sub][atr[sub] == k], qtr[sub][atr[sub] == k]); qms.append(mk)
            t_pred = lambda Xf, qms=qms: np.stack([mk.predict(Xf) for mk in qms], 1)
            mu = t_pred(Xte)
        out = dict(prob=c.predict_proba(Xte), pri=r.predict(Xte), mu=mu)
        t1 = time.time()
        tl = time.perf_counter(); c.predict_proba(Xte[:12]); r.predict(Xte[:12]); lat = (time.perf_counter() - tl) * 1000 / 12
        m = T.metrics(D, te, out)
        m.update(train_time_s=t1 - t0, latency_ms=lat, meta=meta)
        if name in ("HGB", "RF"):                     # identical perturbations to run_exp.robustness
            rob = {}
            rng = np.random.default_rng(100 + seed)
            X0 = D.X[te]

            def feats(Xp):                            # same descriptors as Dataset.handcrafted
                t_ = np.arange(Xp.shape[2]) - (Xp.shape[2] - 1) / 2
                k = max(1, min(5, Xp.shape[2] // 2))
                f = np.concatenate([Xp.mean(2), Xp.std(2), Xp[:, :, -1], Xp[:, :, -k:].mean(2) - Xp[:, :, :k].mean(2),
                                    Xp.min(2), Xp.max(2), (Xp * t_[None, None, :, None]).sum(2) / (t_ ** 2).sum(), D.Sx[te]], -1)
                return f.reshape(-1, f.shape[-1])

            def ev(Xf):
                mu_ = s_learner_pred(Xf) if meta == "S" else t_pred(Xf)
                o = dict(prob=c.predict_proba(Xf), pri=r.predict(Xf), mu=mu_)
                mm = T.metrics(D, te, o)
                return {k: mm[k] for k in ["F1", "Acc", "R2", "MAE", "V", "NPV", "OptRate", "PEHE", "Regret"]}
            for pdrop in (0.1, 0.2, 0.3, 0.4):
                drop = rng.random(X0.shape[:2] + (1, X0.shape[3])) < pdrop
                rob[f"drop{pdrop}"] = ev(feats(np.where(drop, 0.0, X0)))
            for sg in (0.1, 0.25, 0.5, 0.75):
                rob[f"noise{sg}"] = ev(feats(X0 + rng.normal(0, sg, X0.shape)))
            for tl in (4, 8, 12, 16):
                rob[f"len{tl}"] = ev(feats(X0[:, :, -tl:]))
            m["robust"] = rob
        res[name] = m
        print(name, {k: round(v, 3) for k, v in m.items() if isinstance(v, float) and k in
                     ("F1", "Acc", "R2", "MAE", "V", "NPV", "PEHE", "OptRate")}, flush=True)
        np.savez_compressed(f"{OUT}/pred_main_{name}_s{seed}.npz", **out)
    # historical coach policy & static rules (decision references)
    Q = D.Q[te].reshape(-1, K); a = D.a[te].ravel(); y = D.y[te].ravel()
    rule = np.array([0, 1, 2, 4])[y]            # oracle-state canonical rule (upper bound of rule-based coaching)
    res["_policies"] = dict(Coach=float(Q[np.arange(len(a)), a].mean()), Oracle=float(Q.max(1).mean()),
                            Random=float(Q.mean()), RuleOracleState=float(Q[np.arange(len(a)), rule].mean()),
                            AlwaysMaintain=float(Q[:, 0].mean()),
                            CoachOptRate=float((a == Q.argmax(1)).mean()),
                            RuleOptRate=float((rule == Q.argmax(1)).mean()))
    json.dump(res, open(f"{OUT}/classical_s{seed}.json", "w"), indent=1)
    print(res["_policies"])


if __name__ == "__main__":
    run(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
