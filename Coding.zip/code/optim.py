"""
optim.py -- metaheuristic optimisers on the unit box [0,1]^D (minimisation).

CLEAR-GWO (proposed): Chaotic, Levy-enhanced, Elite-opposition, Adaptive dimension-learning,
Resource-aware Grey Wolf Optimizer
  C  piecewise-linear chaotic map (PWLCM) population initialisation
  L  Levy-flight perturbation of omega wolves around the alpha (prob. decays over time)
  E  elite exploitation: Gaussian local search around the alpha (step shrinks with leader spread)
     plus elite opposition-based learning on stagnation
  A  adaptive dimension-learning hunting (DLH) whose usage probability tracks its success rate,
     fitness-weighted alpha/beta/delta leadership and an exponential non-linear convergence factor
  R  resource-aware (latency/MAC-penalised) fitness, used when tuning SPRINT

Baselines: Random Search (RS), PSO, DE (rand/1/bin), WOA, GWO (canonical), I-GWO (DLH, 2 evals/wolf).
Every optimiser is budgeted by the number of objective evaluations (fair comparison).
"""
import numpy as np
from math import gamma, sin, pi


def _levy(rng, shape, beta=1.5):
    s = (gamma(1 + beta) * sin(pi * beta / 2) / (gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
    u = rng.normal(0, s, shape); v = rng.normal(0, 1, shape)
    return u / np.abs(v) ** (1 / beta)


def chaotic_init(rng, n, D, p=0.3):
    """piecewise-linear chaotic map (PWLCM) sequence: uniform invariant density, ergodic coverage."""
    x = rng.uniform(0.05, 0.95, D)
    P = np.empty((n, D))
    for _ in range(25):                                   # burn-in
        x = _pwlcm(x, p)
    for i in range(n):
        x = _pwlcm(x, p)
        P[i] = x
    return np.clip(P, 1e-6, 1 - 1e-6)


def _pwlcm(x, p):
    y = np.where(x >= 0.5, 1.0 - x, x)
    y = np.where(y < p, y / p, (y - p) / (0.5 - p))
    return np.clip(y, 1e-9, 1 - 1e-9)


class Tracker:
    def __init__(self, f, budget):
        self.f, self.budget, self.n = f, budget, 0
        self.best, self.bx, self.curve, self.log = np.inf, None, [], []

    def __call__(self, x):
        if self.n >= self.budget:
            return np.inf
        v = float(self.f(np.clip(x, 0, 1)))
        self.n += 1
        if v < self.best:
            self.best, self.bx = v, np.clip(x, 0, 1).copy()
        self.curve.append(self.best); self.log.append((self.n, v, np.clip(x, 0, 1).copy()))
        return v

    @property
    def done(self):
        return self.n >= self.budget


def random_search(f, D, budget, pop=10, seed=0):
    rng = np.random.default_rng(seed); tr = Tracker(f, budget)
    while not tr.done:
        tr(rng.random(D))
    return tr


def pso(f, D, budget, pop=10, seed=0, w0=0.9, w1=0.4, c1=2.0, c2=2.0):
    rng = np.random.default_rng(seed); tr = Tracker(f, budget)
    X = rng.random((pop, D)); V = rng.uniform(-0.1, 0.1, (pop, D))
    fx = np.array([tr(x) for x in X]); pb, pf = X.copy(), fx.copy()
    T = max(1, budget // pop - 1); t = 0
    while not tr.done:
        w = w0 - (w0 - w1) * t / T
        g = pb[pf.argmin()]
        V = w * V + c1 * rng.random((pop, D)) * (pb - X) + c2 * rng.random((pop, D)) * (g - X)
        V = np.clip(V, -0.25, 0.25); X = np.clip(X + V, 0, 1)
        for i in range(pop):
            v = tr(X[i])
            if v < pf[i]:
                pf[i], pb[i] = v, X[i].copy()
        t += 1
    return tr


def de(f, D, budget, pop=10, seed=0, F=0.5, CR=0.9):
    rng = np.random.default_rng(seed); tr = Tracker(f, budget)
    X = rng.random((pop, D)); fx = np.array([tr(x) for x in X])
    while not tr.done:
        for i in range(pop):
            a, b, c = X[rng.choice([j for j in range(pop) if j != i], 3, replace=False)]
            m = np.clip(a + F * (b - c), 0, 1)
            cr = rng.random(D) < CR; cr[rng.integers(D)] = True
            u = np.where(cr, m, X[i]); v = tr(u)
            if v <= fx[i]:
                X[i], fx[i] = u, v
    return tr


def woa(f, D, budget, pop=10, seed=0, b=1.0):
    rng = np.random.default_rng(seed); tr = Tracker(f, budget)
    X = rng.random((pop, D)); fx = np.array([tr(x) for x in X])
    T = max(1, budget // pop - 1); t = 0
    while not tr.done:
        best = X[fx.argmin()].copy(); a = 2 - 2 * t / T
        for i in range(pop):
            r1, r2, p = rng.random(D), rng.random(D), rng.random()
            A, C = 2 * a * r1 - a, 2 * r2
            if p < 0.5:
                ref = best if np.abs(A).mean() < 1 else X[rng.integers(pop)]
                X[i] = ref - A * np.abs(C * ref - X[i])
            else:
                l = rng.uniform(-1, 1)
                X[i] = np.abs(best - X[i]) * np.exp(b * l) * np.cos(2 * pi * l) + best
            X[i] = np.clip(X[i], 0, 1); fx[i] = tr(X[i])
        t += 1
    return tr


def gwo(f, D, budget, pop=10, seed=0):
    rng = np.random.default_rng(seed); tr = Tracker(f, budget)
    X = rng.random((pop, D)); fx = np.array([tr(x) for x in X])
    T = max(1, budget // pop - 1); t = 0
    while not tr.done:
        o = np.argsort(fx); Xa, Xb, Xd = X[o[0]].copy(), X[o[1]].copy(), X[o[2]].copy()
        a = 2 - 2 * t / T
        for i in range(pop):
            cand = []
            for L in (Xa, Xb, Xd):
                A = 2 * a * rng.random(D) - a; C = 2 * rng.random(D)
                cand.append(L - A * np.abs(C * L - X[i]))
            X[i] = np.clip(np.mean(cand, 0), 0, 1); fx[i] = tr(X[i])
        t += 1
    return tr


def igwo(f, D, budget, pop=10, seed=0):
    """I-GWO with dimension learning-based hunting (two candidate evaluations per wolf)."""
    rng = np.random.default_rng(seed); tr = Tracker(f, budget)
    X = rng.random((pop, D)); fx = np.array([tr(x) for x in X])
    T = max(1, budget // (2 * pop)); t = 0
    while not tr.done:
        o = np.argsort(fx); Xa, Xb, Xd = X[o[0]].copy(), X[o[1]].copy(), X[o[2]].copy()
        a = 2 - 2 * t / T
        for i in range(pop):
            cand = []
            for L in (Xa, Xb, Xd):
                A = 2 * a * rng.random(D) - a; C = 2 * rng.random(D)
                cand.append(L - A * np.abs(C * L - X[i]))
            xg = np.clip(np.mean(cand, 0), 0, 1)
            R = np.linalg.norm(X[i] - xg)
            nb = np.where(np.linalg.norm(X - X[i], axis=1) <= R)[0]
            nb = nb if len(nb) else np.array([i])
            xd = np.clip(X[i] + rng.random(D) * (X[rng.choice(nb)] - X[rng.integers(pop)]), 0, 1)
            fg = tr(xg); fd = tr(xd)
            if min(fg, fd) < fx[i]:
                X[i], fx[i] = (xg, fg) if fg <= fd else (xd, fd)
        t += 1
    return tr


def clear_gwo(f, D, budget, pop=10, seed=0, stall=3, beta=1.5, k_exp=6.0, sig0=0.1, wt=3.0,
              use_chaos=True, use_levy=True, use_elite=True, use_dlh=True, use_weights=True, sched="exp"):
    """CLEAR-GWO. Flags allow component ablation (see optimizer ablation experiment)."""
    rng = np.random.default_rng(seed); tr = Tracker(f, budget)
    X = chaotic_init(rng, pop, D) if use_chaos else rng.random((pop, D))
    fx = np.array([tr(x) for x in X])
    T = max(1, budget // (pop + (1 if use_elite else 0)) - 1); t = 0
    p_dlh, succ_g, succ_d, n_g, n_d = 0.3, 1.0, 1.0, 2.0, 2.0
    last_best, stagn = fx.min(), 0
    while not tr.done:
        o = np.argsort(fx); lead = X[o[:3]].copy(); lf = fx[o[:3]]
        if use_weights:                                                         # fitness-weighted leadership
            w = np.exp(-(lf - lf.min()) / (np.abs(lf).mean() + 1e-12) * wt); w /= w.sum()
        else:
            w = np.ones(3) / 3
        r = min(1.0, t / T)
        a = 2.0 * np.exp(-k_exp * r) if sched == "exp" else 2.0 - 2.0 * r      # non-linear convergence factor
        pL = 0.35 * (1 - r)
        for i in range(pop):
            if tr.done:
                break
            ud = use_dlh and rng.random() < p_dlh
            if not ud:
                cand = []
                for L in lead:
                    A = 2 * a * rng.random(D) - a; C = 2 * rng.random(D)
                    cand.append(L - A * np.abs(C * L - X[i]))
                xn = (w[:, None] * np.array(cand)).sum(0)
                if use_levy and i not in o[:3] and rng.random() < pL:         # Levy flight for omega wolves
                    xn = xn + 0.05 * _levy(rng, D, beta) * (xn - lead[0] + 1e-3)
            else:                                                             # adaptive dimension-learning hunting
                ref = (w[:, None] * lead).sum(0)
                R = np.linalg.norm(X[i] - ref) + 1e-9
                nb = np.where(np.linalg.norm(X - X[i], axis=1) <= R)[0]
                nb = nb if len(nb) else np.array([i])
                xn = X[i] + rng.random(D) * (X[rng.choice(nb)] - X[rng.integers(pop)])
            xn = np.clip(xn, 0, 1); v = tr(xn)
            ok = v < fx[i]
            if ud:
                n_d += 1; succ_d += ok
            else:
                n_g += 1; succ_g += ok
            if ok:                                                            # greedy, memory-preserving selection
                X[i], fx[i] = xn, v
        if use_dlh:
            p_dlh = float(np.clip((succ_d / n_d) / (succ_d / n_d + succ_g / n_g), 0.1, 0.6))
        if use_elite and not tr.done:                                         # elite Gaussian local exploitation
            b = fx.argmin(); spread = X[np.argsort(fx)[:3]].std(0) + 1e-6
            xe = np.clip(X[b] + rng.normal(0, 1, D) * spread * (sig0 + (1 - r)), 0, 1); v = tr(xe)
            if v < fx[b]:
                X[b], fx[b] = xe, v
        if fx.min() < last_best - 1e-12:
            last_best, stagn = fx.min(), 0
        else:
            stagn += 1
        if use_elite and stagn >= stall and not tr.done:                      # elite opposition on stagnation
            oo = np.argsort(fx); al, au = X[oo[:3]].min(0), X[oo[:3]].max(0)
            j = fx.argmax()
            xo = np.clip(rng.random(D) * (al + au) - X[j], 0, 1); v = tr(xo)
            if v < fx[j]:
                X[j], fx[j] = xo, v
            stagn = 0
        t += 1
    return tr


OPTIMIZERS = dict(RS=random_search, PSO=pso, DE=de, WOA=woa, GWO=gwo, IGWO=igwo, CLEAR_GWO=clear_gwo)


# ---------------- classical benchmark functions (mapped from [0,1]^D) ----------------
def _map(x, lo, hi):
    return lo + (hi - lo) * x


BENCH = {
    "F1 Sphere": (lambda z: np.sum(z ** 2), -100, 100),
    "F2 Schwefel 2.22": (lambda z: np.sum(np.abs(z)) + np.prod(np.abs(z)), -10, 10),
    "F3 Rosenbrock": (lambda z: np.sum(100 * (z[1:] - z[:-1] ** 2) ** 2 + (z[:-1] - 1) ** 2), -30, 30),
    "F4 Rastrigin": (lambda z: np.sum(z ** 2 - 10 * np.cos(2 * pi * z) + 10), -5.12, 5.12),
    "F5 Ackley": (lambda z: -20 * np.exp(-0.2 * np.sqrt(np.mean(z ** 2))) - np.exp(np.mean(np.cos(2 * pi * z))) + 20 + np.e, -32, 32),
    "F6 Griewank": (lambda z: np.sum(z ** 2) / 4000 - np.prod(np.cos(z / np.sqrt(np.arange(1, len(z) + 1)))) + 1, -600, 600),
    "F7 Levy": (lambda z: (lambda w: np.sin(pi * w[0]) ** 2 + np.sum((w[:-1] - 1) ** 2 * (1 + 10 * np.sin(pi * w[:-1] + 1) ** 2))
                           + (w[-1] - 1) ** 2 * (1 + np.sin(2 * pi * w[-1]) ** 2))(1 + (z - 1) / 4), -10, 10),
    "F8 Zakharov": (lambda z: np.sum(z ** 2) + np.sum(0.5 * np.arange(1, len(z) + 1) * z) ** 2 +
                    np.sum(0.5 * np.arange(1, len(z) + 1) * z) ** 4, -5, 10),
}


def bench_fn(name, shift_seed=0):
    f, lo, hi = BENCH[name]
    sh = np.random.default_rng(1000 + shift_seed).uniform(-0.2, 0.2) * (hi - lo) * 0.25 if name not in ("F3 Rosenbrock",) else 0.0
    return lambda x: f(_map(x, lo, hi) - sh)
