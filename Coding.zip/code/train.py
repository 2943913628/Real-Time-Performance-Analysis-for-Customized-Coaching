"""train.py -- multi-task, counterfactual-aware training loop and evaluation metrics."""
import numpy as np, time
import autograd as ag
from autograd import AdamW, cross_entropy, mse, no_grad
from sklearn.metrics import (accuracy_score, f1_score, cohen_kappa_score, matthews_corrcoef, roc_auc_score,
                             mean_absolute_error, mean_squared_error, r2_score)

K = 5


def softmax_np(x):
    e = np.exp(x - x.max(-1, keepdims=True))
    return e / e.sum(-1, keepdims=True)


def recommend(mu, p_state, safety=True, tau=0.5):
    """safety-constrained customised intervention: never 'Intensify' when strain risk is high."""
    m = mu.copy()
    if safety:
        m[p_state[:, 3] > tau, 1] = -np.inf
    return m.argmax(1)


def predict(model, D, idx, bs=16, X_override=None):
    out = dict(prob=[], pri=[], mu=[], prop=[], emb=[])
    with no_grad():
        for i in range(0, len(idx), bs):
            b = D.batch(idx[i:i + bs])
            if X_override is not None:
                b["X"] = X_override[i:i + bs]
            o = model(b, train=False)
            out["prob"].append(softmax_np(o["logits"].data)); out["pri"].append(o["pri"].data)
            out["mu"].append(o["mu"].data); out["prop"].append(softmax_np(o["prop"].data))
            out["emb"].append(o["emb"].data)
    out = {k: np.concatenate(v) for k, v in out.items()}
    out["pri"] = out["pri"] * D.pri_sd + D.pri_mu
    out["mu"] = out["mu"] * D.q_sd + D.q_mu
    return out


def dr_value(pi, mu, a, q, prop):
    """doubly-robust off-policy value estimate with logged propensities (observable at deployment)."""
    n = len(pi)
    pa = prop[np.arange(n), a]
    return float(np.mean(mu[np.arange(n), pi] + (a == pi) / pa * (q - mu[np.arange(n), a])))


def metrics(D, idx, out, safety=True, sel=None):
    y = D.y[idx].ravel(); pri = D.pri[idx].ravel(); Q = D.Q[idx].reshape(-1, K)
    a = D.a[idx].ravel(); q = D.q[idx].ravel(); prop_log = D.prop_true[idx].reshape(-1, K)
    if sel is not None:
        sel = np.asarray(sel).ravel()
        y, pri, Q, a, q, prop_log = y[sel], pri[sel], Q[sel], a[sel], q[sel], prop_log[sel]
        out = {k: v[sel] for k, v in out.items()}
    yp = out["prob"].argmax(1)
    pi = recommend(out["mu"], out["prob"], safety)
    best = Q.argmax(1)
    V = Q[np.arange(len(pi)), pi].mean(); Vor = Q.max(1).mean(); Vr = Q.mean()
    Vcoach = Q[np.arange(len(a)), a].mean()
    tau_hat = out["mu"][:, 1:] - out["mu"][:, :1]; tau = Q[:, 1:] - Q[:, :1]
    try:
        auc = roc_auc_score(y, out["prob"], multi_class="ovr", average="macro")
    except Exception:
        auc = np.nan
    m = dict(Acc=accuracy_score(y, yp), F1=f1_score(y, yp, average="macro"),
             wF1=f1_score(y, yp, average="weighted"), Kappa=cohen_kappa_score(y, yp),
             MCC=matthews_corrcoef(y, yp), AUC=auc,
             MAE=mean_absolute_error(pri, out["pri"]), RMSE=np.sqrt(mean_squared_error(pri, out["pri"])),
             R2=r2_score(pri, out["pri"]),
             V=V, Regret=Vor - V, OptRate=(pi == best).mean(), PEHE=np.sqrt(((tau_hat - tau) ** 2).mean()),
             NPV=(V - Vr) / (Vor - Vr), Vcoach=Vcoach, Voracle=Vor, Vrandom=Vr,
             SafetyViol=float(((pi == 1) & (y == 3)).mean()),
             V_DR=dr_value(pi, out["mu"], a, q, prop_log))
    m["J"] = 0.5 * m["F1"] + 0.25 * max(m["R2"], 0) + 0.25 * m["NPV"]
    # observable selection criterion (no counterfactual ground truth): DR-normalised value
    m["J_obs"] = 0.5 * m["F1"] + 0.25 * max(m["R2"], 0) + 0.25 * float(np.clip((m["V_DR"] - q.mean()) / q.std(), -1, 1))
    return {k: float(v) for k, v in m.items()}


def fit(model, D, cfg, epochs=12, bs=8, train_idx=None, verbose=False, seed=0, patience=4, select="J_obs",
        time_budget=None, val_idx=None, loss_mask=None):
    rng = np.random.default_rng(seed)
    params = model.parameters()
    opt = AdamW(params, lr=float(cfg.get("lr", 3e-3)), wd=float(cfg.get("wd", 1e-4)))
    tr = D.split["train"] if train_idx is None else train_idx
    va = D.split["val"] if val_idx is None else val_idx
    lam_r, lam_q, lam_p = float(cfg.get("lam_r", 0.5)), float(cfg.get("lam_q", 1.0)), float(cfg.get("lam_p", 0.3))
    cf = cfg.get("flags", {}).get("cf", True)
    steps = epochs * int(np.ceil(len(tr) / bs)); step = 0
    best, best_sd, hist, bad = -1e9, None, [], 0
    t0 = time.time()
    for ep in range(epochs):
        perm = rng.permutation(tr)
        tl = []
        aug = cfg.get("augment", False)
        for i in range(0, len(perm), bs):
            b = D.batch(perm[i:i + bs])
            if aug:                                     # physiology-consistent stochastic augmentation
                X = b["X"].copy()
                pm = rng.uniform(0, 0.15)
                X = np.where(rng.random(X.shape[:2] + (1, X.shape[3])) < pm, 0.0, X)   # sensor drop-out
                X = X + rng.normal(0, 0.05, X.shape)                                     # sensor jitter
                if rng.random() < 0.3:                                                   # anytime crop
                    tcrop = int(rng.integers(8, X.shape[2] + 1)); X = X[:, :, -tcrop:]
                b["X"] = X
            o = model(b, train=True)
            y = b["y"].ravel(); a = b["a"].ravel(); n = len(y)
            lm = np.ones(n) if loss_mask is None else loss_mask[perm[i:i + bs]].ravel().astype(float)
            w_cls = D.class_w[y] * lm
            L = cross_entropy(o["logits"], y, weight=w_cls, smoothing=0.05)
            L = L + lam_r * mse(o["pri"], (b["pri"].ravel() - D.pri_mu) / D.pri_sd, weight=lm)
            mu_a = o["mu"][np.arange(n), a]
            if cf:
                pa = softmax_np(o["prop"].data)[np.arange(n), a]
                w = np.clip(1.0 / (K * pa), 0.2, 5.0) if ep > 0 else np.ones(n)
                L = L + lam_q * mse(mu_a, (b["q"].ravel() - D.q_mu) / D.q_sd, weight=w / w.mean() * lm)
                if lam_p > 0:
                    L = L + lam_p * cross_entropy(o["prop"], a, weight=lm)
            else:
                L = L + lam_q * mse(mu_a, (b["q"].ravel() - D.q_mu) / D.q_sd, weight=lm)
            opt.zero_grad(); L.backward()
            lr = opt.lr * 0.5 * (1 + np.cos(np.pi * step / steps)) * min(1.0, (step + 1) / 30)
            opt.step(lr); step += 1
            tl.append(float(L.data))
        mv = metrics(D, va, predict(model, D, va))
        hist.append(dict(epoch=ep, loss=float(np.mean(tl)), **{f"val_{k}": v for k, v in mv.items()},
                         time=time.time() - t0))
        if verbose:
            print(f"ep{ep} loss {np.mean(tl):.3f} valF1 {mv['F1']:.3f} R2 {mv['R2']:.3f} NPV {mv['NPV']:.3f} "
                  f"J_obs {mv['J_obs']:.3f} t {time.time() - t0:.0f}s", flush=True)
        if mv[select] > best:
            best, best_sd, bad = mv[select], model.state_dict(), 0
        else:
            bad += 1
            if bad >= patience:
                break
        if time_budget and time.time() - t0 > time_budget:
            break
    model.load_state_dict(best_sd)
    return hist


def latency(model, D, n_rep=30):
    """single-snapshot (one squad, 12 athletes) streaming inference latency in ms per athlete-window."""
    idx = D.split["test"][:1]
    b = D.batch(idx)
    with no_grad():
        model(b, train=False)
        ts = []
        for _ in range(n_rep):
            t = time.perf_counter(); model(b, train=False); ts.append(time.perf_counter() - t)
    ts = np.array(ts) * 1000 / D.N
    return float(np.median(ts)), float(np.percentile(ts, 95))
