"""hpo.py -- resource-aware hyper-parameter optimisation of SPRINT with CLEAR-GWO and competitors."""
import numpy as np, json, os, sys, time
import autograd as ag
ag.set_dtype(np.float32)
from data import Dataset
from models import SPRINT
import train as T
import optim

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
D_SPACE = ["d", "L", "heads", "k_peer", "lr", "dropout", "lam_q", "lam_p", "lam_r"]
MAC_BUDGET = 1.0e6          # per athlete-window (edge budget)
RHO = 0.05                  # resource penalty weight


def decode(x):
    x = np.clip(x, 0, 1 - 1e-9)
    return dict(d=[16, 24, 32, 40][int(x[0] * 4)], L=[1, 2][int(x[1] * 2)], heads=[1, 2, 4][int(x[2] * 3)],
                k_peer=2 + int(x[3] * 7), lr=float(10 ** (-3.3 + 1.3 * x[4])), dropout=float(0.3 * x[5]),
                lam_q=float(0.3 + 1.7 * x[6]), lam_p=float(0.05 + 0.55 * x[7]), lam_r=float(0.2 + 1.3 * x[8]),
                enc_dropout=float(0.3 * x[5]), augment=True)


def macs(cfg, C=12, T=20, P=32, N=12, K=5):
    d, L = cfg["d"], cfg["L"]; Tp = T // 4; tok = Tp * C
    m = tok * 4 * d
    blk = 2 * tok * (4 * d * d + d * d) + 2 * C * d * d                       # MS-GTA (dilations 1, 2)
    blk += C * 2 * d * d + C * C * d + Tp * C * C * d + tok * d * d            # TAG
    m += L * blk
    m += C * d * d + tok * d * d + tok * d                                     # recency pooling
    m += C * 7 * d + C * 2 * d * d + 2 * C * C * d + C * d * d                 # descriptor branch + post graph
    m += C * d * d + C * d * d + P * d + 2 * d * d                             # read-out (attn + flat) + FiLM
    m += 4 * d * d + 2 * N * d                                                 # peer attention
    m += (2 * d + P) * d + 10 * d + K * ((d + 4) * d + d)                      # heads (with context skip)
    return float(m)


def main(opt_name, budget=24, pop=6, seed=0, frac=0.30, epochs=6):
    D = Dataset()
    rng = np.random.default_rng(1234)
    sub = np.sort(rng.choice(D.split["train"], int(frac * len(D.split["train"])), replace=False))
    log = []
    t0 = time.time()

    def fitness(x):
        cfg = decode(x)
        m = SPRINT(D.C, D.T, D.P, D.A_prior, cfg, seed=seed)
        h = T.fit(m, D, cfg, epochs=epochs, train_idx=sub, seed=seed, patience=10)
        j = max(e["val_J_obs"] for e in h)
        mc = macs(cfg)
        fit = 1 - j + RHO * max(0.0, mc / MAC_BUDGET - 1)
        log.append(dict(n=len(log) + 1, cfg=cfg, J_obs=j, macs=mc, fitness=fit, t=time.time() - t0))
        print(f"[{opt_name}] eval {len(log)} J_obs={j:.4f} MACs={mc / 1e6:.2f}M fit={fit:.4f} cfg={cfg}", flush=True)
        json.dump(dict(optimizer=opt_name, log=log), open(f"{OUT}/hpo_{opt_name}.json", "w"), indent=1)
        return fit

    tr = optim.OPTIMIZERS[opt_name](fitness, len(D_SPACE), budget, pop=pop, seed=seed)
    best = decode(tr.bx)
    json.dump(dict(optimizer=opt_name, log=log, best_cfg=best, best_fitness=tr.best, curve=tr.curve,
                   time_s=time.time() - t0), open(f"{OUT}/hpo_{opt_name}.json", "w"), indent=1)
    print("BEST", opt_name, tr.best, best)


if __name__ == "__main__":
    main(sys.argv[1], budget=int(sys.argv[2]) if len(sys.argv) > 2 else 30)
