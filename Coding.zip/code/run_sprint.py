"""wrapper: waits for the HPO result of a given optimiser, then launches run_exp with that configuration."""
import json, os, sys, time, subprocess, argparse
ap = argparse.ArgumentParser()
ap.add_argument("--src", default="CLEAR_GWO"); ap.add_argument("--flags", default="{}")
ap.add_argument("--seed", default="0"); ap.add_argument("--tag", default="main"); ap.add_argument("--setting", default="main")
ap.add_argument("--robust", default="0"); ap.add_argument("--save", default="0"); ap.add_argument("--epochs", default="30")
A = ap.parse_args()
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
DEFAULT = dict(d=32, L=1, heads=2, k_peer=4, lr=3e-3, dropout=0.1, enc_dropout=0.1, lam_q=1.0, lam_p=0.3, lam_r=0.5,
               augment=True)
if A.src == "default":
    cfg = dict(DEFAULT)
else:
    f = f"{R}/hpo_{A.src}.json"
    while True:
        try:
            j = json.load(open(f))
            if "best_cfg" in j:
                cfg = j["best_cfg"]; break
        except Exception:
            pass
        time.sleep(20)
fl = json.loads(A.flags)
if fl.pop("augment", True) is False:
    cfg["augment"] = False
cfg["flags"] = fl
cmd = ["python3", "run_exp.py", "--model", "SPRINT", "--seed", A.seed, "--cfg", json.dumps(cfg), "--tag", A.tag,
       "--setting", A.setting, "--robust", A.robust, "--save", A.save, "--epochs", A.epochs, "--patience", "6"]
sys.exit(subprocess.call(cmd, cwd=os.path.dirname(os.path.abspath(__file__))))
