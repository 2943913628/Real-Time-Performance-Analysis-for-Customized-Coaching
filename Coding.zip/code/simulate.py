"""
simulate.py -- physiology-grounded digital-twin simulator of college sports training.

Generates the CS-PERFORM benchmark used in the paper:
  * 96 collegiate athletes, 4 sports (basketball, soccer, track sprint, volleyball),
    8 squads of 12, 36 sessions per squad (12-week semester, 3 sessions/week),
    6 five-minute windows per session, 20 epochs (15 s) per window, 12 wearable channels.
  * Per athlete-window labels: real-time performance state (4 classes), Performance
    Readiness Index (PRI, 0-100), the coach's observed intervention (5 options), the
    observed outcome, AND the full set of potential outcomes under every intervention
    (available only because the data are simulated -> enables exact counterfactual
    evaluation of personalised coaching policies).

Day-to-day load follows the Banister fitness-fatigue impulse-response model; within-session
latent metabolic fatigue, neuromuscular fatigue and technique degradation evolve with relative
stimulus and athlete traits; sensors are noisy, lagged, nonlinear read-outs of the latent state.
All numbers are synthetic. Ranges were set to typical published values for wearable monitoring
in team and individual sports (heart rate, RMSSD, SmO2, ground-contact time, PlayerLoad, ...).
"""
import numpy as np, pandas as pd, json, os, sys

SEED = 20260519
CH = ["HR_bpm", "RMSSD_ms", "RespRate_bpm", "SkinTemp_C", "Speed_mps", "AccelLoad_ms2",
      "PlayerLoad_au", "SmO2_pct", "GCT_ms", "StrideFreq_Hz", "Stiffness_idx", "Asymmetry_pct"]
SPORTS = ["Basketball", "Soccer", "TrackSprint", "Volleyball"]
STATES = ["Optimal", "Under-stimulated", "Metabolic fatigue", "Neuromuscular strain"]
INTERV = ["Maintain", "Intensify", "Load modulation", "Technical cueing", "Active recovery"]
N_PER_SQUAD, SQUADS_PER_SPORT, N_SESS, N_WIN, T = 12, 2, 36, 6, 20

# sport-specific multipliers: speed, accel, impact (neuromuscular), vmax
SPORT_P = {"Basketball": dict(sp=0.75, ac=1.25, imp=1.10, vmax=6.8, duty=0.55, per=5),
           "Soccer": dict(sp=1.00, ac=1.00, imp=0.85, vmax=8.2, duty=0.60, per=7),
           "TrackSprint": dict(sp=1.20, ac=1.10, imp=1.25, vmax=9.6, duty=0.35, per=8),
           "Volleyball": dict(sp=0.55, ac=0.90, imp=1.35, vmax=6.0, duty=0.45, per=4)}
I_MULT = np.array([1.00, 1.25, 0.70, 0.95, 0.35])     # demand multiplier per intervention
M_REC = np.array([1.00, 0.95, 1.45, 1.10, 2.10])      # metabolic-recovery multiplier
N_REC = np.array([1.00, 0.95, 1.25, 1.20, 1.80])      # neuromuscular-recovery multiplier


def sig(x):
    return 1 / (1 + np.exp(-x))


def make_athletes(rng):
    rows = []
    aid = 0
    for s_i, sp in enumerate(SPORTS):
        for q in range(SQUADS_PER_SPORT):
            sq = s_i * SQUADS_PER_SPORT + q
            for k in range(N_PER_SQUAD):
                sex = int(rng.random() < 0.5)
                fit, res, nm, tech, rec = rng.normal(0, 1, 5)
                ready = rng.normal(0, 0.35)                     # individual readiness offset (unobserved)
                pos = int(rng.integers(0, 3))
                age = rng.uniform(18, 23.5)
                tage = np.clip(rng.normal(5 + 0.6 * (age - 18), 1.8), 1, 14)
                mass = rng.normal(72 + 10 * (1 - sex) + (6 if sp == "Basketball" else 0) +
                                  (4 if sp == "Volleyball" else 0), 6)
                vo2 = 48 + 6 * (1 - sex) + 4.0 * fit + rng.normal(0, 2.0)   # observed proxy of fitness
                hrmax = 208 - 0.7 * age + rng.normal(0, 4)
                hrrest = 58 - 4 * fit + rng.normal(0, 3)
                rows.append(dict(athlete_id=aid, sport=sp, squad=sq, position=pos, sex_male=1 - sex,
                                 age=age, training_age=tage, body_mass=mass, vo2max=vo2,
                                 hr_max=hrmax, hr_rest=hrrest,
                                 lat_fitness=fit, lat_fatigue_res=res, lat_nm_robust=nm,
                                 lat_technique=tech, lat_recovery=rec, lat_readiness=ready))
                aid += 1
    return pd.DataFrame(rows)


def latent_step(I, cap, m, n, A, k, sport_imp, rng_eps):
    """one 5-min window of latent dynamics under intervention k (vectorised over athletes)."""
    s = I / cap
    lam_m = 0.55 * (1 + 0.20 * A["rec"]) * M_REC[k]
    lam_n = 0.30 * (1 + 0.15 * A["rec"]) * N_REC[k]
    m_new = m * np.exp(-lam_m) + 1.60 * np.maximum(0, s - 0.50) ** 1.5 * (1 - 0.18 * A["res"]) + rng_eps[0]
    n_new = n * np.exp(-lam_n) + 0.42 * sport_imp * I ** 2 * (1 - 0.18 * A["nm"]) + 0.16 * m_new + rng_eps[1]
    m_new, n_new = np.maximum(m_new, 0), np.maximum(n_new, 0)
    k = np.broadcast_to(np.asarray(k), I.shape)
    tmult = np.where(k == 3, 0.45 + 0.20 * np.tanh(A["tech"]), 1.0)   # cueing helps poor-technique athletes most
    tdeg = sig(3.2 * (n_new + 0.35 * m_new - 1.05 - 0.30 * A["tech"])) * tmult
    return s, m_new, n_new, tdeg


def effectiveness(s, m, n, tdeg, A, k=None):
    """training-effectiveness outcome Q of a window (higher = better adaptation/risk balance)."""
    s_opt = 0.92 + 0.06 * A["res"]
    benefit = 2.4 * (2.0 * s_opt * s - 1.0 * s ** 2)  # concave dose-response, peaks at s_opt
    if k is not None:
        benefit = benefit * np.where(np.broadcast_to(np.asarray(k), s.shape) == 3, 0.92, 1.0)  # cueing time cost
    cost = 1.0 * m ** 2 + 0.3 * m + 3.0 * np.maximum(0, tdeg - 0.32) + 0.9 * np.maximum(0, n - 0.90)
    return 10 * (benefit - cost)


def simulate(seed=SEED, outdir="../data"):
    rng = np.random.default_rng(seed)
    ath = make_athletes(rng)
    n_ath = len(ath)
    # ---- daily load history (Banister) ----
    days = N_SESS // 3 * 7
    sess_days = np.array([d for d in range(days) if d % 7 in (0, 2, 4)])[:N_SESS]
    snaps, stream, wins = [], [], []
    snap_id = 0
    # athlete state across sessions
    L_REF = 100.0                                          # reference daily load (AU)
    Fit = 42 * L_REF * rng.uniform(0.8, 1.1, n_ath); Fat = 7 * L_REF * rng.uniform(0.7, 1.2, n_ath)
    acute = 7 * L_REF * rng.uniform(0.8, 1.2, n_ath); chronic = 28 * L_REF * rng.uniform(0.85, 1.1, n_ath)
    last_srpe = np.full(n_ath, 230.0)
    prev_day = np.zeros(n_ath)
    hr_rest_d = ath.hr_rest.values
    # session-type plan per squad per session: microcycle (high, moderate, low/technical)
    for sess in range(N_SESS):
        day = sess_days[sess]
        stype = ["high", "moderate", "technical"][sess % 3]
        if sess // 3 in (3, 7, 11):                       # deload every 4th week
            stype = "technical" if stype == "high" else stype
        base_lo, base_hi = dict(high=(0.80, 1.05), moderate=(0.65, 0.88), technical=(0.50, 0.72))[stype]
        # Banister decay between sessions
        gap = day - prev_day
        Fit *= np.exp(-gap / 42.0); Fat *= np.exp(-gap / 7.0)
        acute *= np.exp(-gap / 7.0); chronic *= np.exp(-gap / 28.0)
        prev_day[:] = day
        resid = np.clip(0.6 * (Fat / (7 * L_REF) - 1.0) + 0.2, 0.0, 1.2)   # residual fatigue at session start
        form = Fit / (42 * L_REF) - Fat / (7 * L_REF)
        sleep = np.clip(rng.normal(7.3 - 0.5 * resid, 0.8), 4.0, 10.0)
        sess_ready = rng.normal(0, 0.25, n_ath)                         # day-to-day psychological readiness
        wellness = np.clip(np.round(3.6 - 0.9 * resid + 0.25 * (sleep - 7.3) + 1.2 * sess_ready +
                                    rng.normal(0, 0.5, n_ath)), 1, 5)
        acwr = (acute / 7.0) / (chronic / 28.0 + 1e-6)
        sess_load = np.zeros(n_ath)
        for sq in range(len(SPORTS) * SQUADS_PER_SPORT):
            idx = np.where(ath.squad.values == sq)[0]
            sp = ath.sport.values[idx[0]]
            P = SPORT_P[sp]
            A = dict(fit=ath.lat_fitness.values[idx], res=ath.lat_fatigue_res.values[idx],
                     nm=ath.lat_nm_robust.values[idx], tech=ath.lat_technique.values[idx],
                     rec=ath.lat_recovery.values[idx])
            pos = ath.position.values[idx]
            pos_mult = np.array([0.95, 1.0, 1.07])[pos]
            hrmax, hrr = ath.hr_max.values[idx], hr_rest_d[idx]
            cap = 1 + 0.16 * A["fit"] + 0.06 * np.clip(form[idx], -1, 1) - 0.05 * (7.3 - sleep[idx]) / 0.8 * 0.3
            m = np.maximum(0, 0.28 * resid[idx] + rng.normal(0, 0.05, len(idx)))
            n = np.maximum(0, 0.32 * resid[idx] + rng.normal(0, 0.05, len(idx)))
            adj = np.ones(len(idx))                       # intervention multiplier carried to next window
            k_prev = np.zeros(len(idx), dtype=int)
            skin = 33.0 + rng.normal(0, 0.3, len(idx))
            hr = hrr + 25 + rng.normal(0, 3, len(idx))
            plan = np.empty(N_WIN)
            plan[0] = rng.uniform(0.45, 0.58)
            plan[1:N_WIN - 1] = rng.uniform(base_lo, base_hi, N_WIN - 2)
            plan[N_WIN - 1] = rng.uniform(base_lo + 0.05, base_hi + 0.05)
            for w in range(N_WIN):
                if w == 0:
                    eff_scale = rng.normal(1.0, 0.09, len(idx))     # session effort / pacing level (persistent)
                    eps = (rng.normal(0, 0.03, len(idx)), rng.normal(0, 0.03, len(idx)))
                else:
                    eff_scale, eps = carry
                I = np.clip(plan[w] * pos_mult * eff_scale * adj, 0.15, 1.35)
                s, m_new, n_new, tdeg = latent_step(I, cap, m, n, A, k_prev, P["imp"], eps)
                # ---------- epoch-level sensor synthesis ----------
                per = P["per"] + rng.integers(-1, 2)
                phase = rng.integers(0, per)
                e_idx = np.arange(T)
                wave = ((e_idx + phase) % per) < max(1, int(round(P["duty"] * per)))
                pattern = 0.55 + 0.75 * wave + 0.08 * rng.normal(size=T)        # shared drill pattern
                frac = (e_idx + 1) / T
                X = np.zeros((len(idx), T, len(CH)))
                for e in range(T):
                    u = np.clip(I * pattern[e] * (1 + 0.05 * rng.normal(size=len(idx))), 0.05, 2.0)
                    me = m + (m_new - m) * frac[e]
                    ne = n + (n_new - n) * frac[e]
                    te = tdeg * frac[e] ** 0.7
                    hr_t = hrr + (hrmax - hrr) * np.clip(0.30 + 0.52 * u / cap, 0, 1.02) + 9.0 * me
                    hr = hr + (hr_t - hr) * 0.40 + rng.normal(0, 1.8, len(idx))
                    rmssd = 62 * np.exp(-0.028 * np.maximum(hr - hrr, 0)) * (1 - 0.30 * np.tanh(me)) * \
                        np.exp(rng.normal(0, 0.12, len(idx))) + 3
                    resp = 13 + 26 * u ** 1.25 + 6.5 * me + rng.normal(0, 1.6, len(idx))
                    skin = skin + 0.035 * u + rng.normal(0, 0.04, len(idx))
                    speed = P["vmax"] * 0.62 * u * P["sp"] / 1.2 * (1 - 0.22 * np.tanh(me) - 0.14 * np.tanh(ne)) + \
                        rng.normal(0, 0.25, len(idx))
                    acc = 2.4 * u * P["ac"] * (1 - 0.20 * np.tanh(ne)) + rng.normal(0, 0.20, len(idx))
                    pl = 7.5 * u * (1 + 0.20 * te + 0.10 * np.tanh(ne)) * P["ac"] + rng.normal(0, 0.45, len(idx))
                    smo2 = 72 - 30 * u / cap - 9 * np.tanh(me) + rng.normal(0, 2.0, len(idx))
                    gct = 235 - 45 * np.clip(u, 0, 1.4) * P["sp"] + 32 * np.tanh(ne) + 14 * te + rng.normal(0, 7, len(idx))
                    sf = 2.4 + 0.95 * np.clip(u, 0, 1.4) * P["sp"] - 0.22 * np.tanh(ne) + rng.normal(0, 0.07, len(idx))
                    stiff = 1.0 - 0.28 * np.tanh(ne) - 0.10 * np.tanh(me) + 0.05 * A["nm"] + rng.normal(0, 0.045, len(idx))
                    asym = 4.0 + 11 * te + 5 * np.tanh(ne) * (1 - 0.3 * np.tanh(A["tech"])) + \
                        np.abs(rng.normal(0, 1.3, len(idx)))
                    X[:, e, :] = np.stack([hr, rmssd, resp, skin, speed, acc, pl, smo2, gct, sf, stiff, asym], 1)
                # missingness (sensor drop-outs)
                miss = rng.random(X.shape) < 0.015
                X[miss] = np.nan
                # ---------- labels ----------
                s_target = plan[w] * pos_mult / cap
                th_m = 0.40 + 0.08 * A["res"]
                state = np.zeros(len(idx), dtype=int)
                under = s < 0.82 * np.maximum(s_target, 0.55)
                state[under] = 1
                state[m_new > th_m] = 2
                state[(tdeg > 0.42) | (n_new > 1.25 + 0.1 * A["nm"])] = 3
                flip = rng.random(len(idx)) < 0.04
                state[flip] = rng.integers(0, 4, flip.sum())
                pri = 100 * sig(1.3 + 0.45 * A["fit"] - 1.6 * m_new - 1.25 * n_new - 0.9 * tdeg +
                                0.35 * np.clip(form[idx], -1, 1) + 0.12 * (sleep[idx] - 7.3) +
                                ath.lat_readiness.values[idx] + sess_ready[idx]) + rng.normal(0, 2.5, len(idx))
                # ---------- potential outcomes of next window under each intervention ----------
                nxt_plan = plan[w + 1] if w + 1 < N_WIN else plan[w] * 0.9   # last window: next = 5-min extension
                eps2 = (rng.normal(0, 0.03, len(idx)), rng.normal(0, 0.03, len(idx)))
                eff2 = 1.0 + 0.80 * (eff_scale - 1.0) + rng.normal(0, 0.045, len(idx))   # AR(1) effort
                Q = np.zeros((len(idx), 5))
                nxt_lat = []
                for k in range(5):
                    I2 = np.clip(nxt_plan * pos_mult * eff2 * I_MULT[k], 0.15, 1.35)
                    s2, m2, n2, t2 = latent_step(I2, cap, m_new, n_new, A, np.full(len(idx), k), P["imp"], eps2)
                    Q[:, k] = effectiveness(s2, m2, n2, t2, A, k)
                    nxt_lat.append((m2, n2))
                # ---------- coach (behaviour) policy: noisy heuristic on observable proxies ----------
                Xf = np.where(np.isnan(X), np.nanmean(X, axis=1, keepdims=True), X)
                hr_drift = (Xf[:, -5:, 0].mean(1) - Xf[:, :5, 0].mean(1))
                spd_rel = Xf[:, :, 4].mean(1) / (Xf[:, :, 4].mean() + 1e-6)
                asym_o = Xf[:, -5:, 11].mean(1)
                util = np.stack([np.full(len(idx), 0.8),
                                 1.6 * (0.95 - spd_rel) * 4 - 0.05 * hr_drift,
                                 0.10 * hr_drift - 0.5 + 0.4 * (wellness[idx] < 3),
                                 0.30 * (asym_o - 8.0),
                                 0.35 * (asym_o - 11.0) + 0.06 * hr_drift - 0.8], 1)
                logits = util / 0.9
                pr = np.exp(logits - logits.max(1, keepdims=True)); pr /= pr.sum(1, keepdims=True)
                pr = 0.75 * pr + 0.25 / 5                      # exploration -> positivity/overlap
                a_obs = np.array([rng.choice(5, p=p) for p in pr])
                q_obs = Q[np.arange(len(idx)), a_obs] + rng.normal(0, 0.5, len(idx))
                # ---------- store ----------
                for j, a in enumerate(idx):
                    wins.append(dict(snap_id=snap_id, athlete_id=int(a), squad=sq, sport=sp, session=sess,
                                     session_type=stype, window=w, slot=j, sleep_h=sleep[a], wellness=wellness[a],
                                     acwr=acwr[a], prev_srpe=last_srpe[a], days_since=float(gap[a]) if sess > 0 else 3.0,
                                     state=int(state[j]), PRI=float(pri[j]), action_obs=int(a_obs[j]),
                                     Q_obs=float(q_obs[j]),
                                     **{f"Q_{k}": float(Q[j, k]) for k in range(5)},
                                     **{f"prop_{k}": float(pr[j, k]) for k in range(5)},
                                     lat_stimulus=float(s[j]), lat_met_fatigue=float(m_new[j]),
                                     lat_nm_fatigue=float(n_new[j]), lat_tech_degr=float(tdeg[j]),
                                     planned_intensity=float(plan[w])))
                stream.append((snap_id, idx, X))
                snaps.append(dict(snap_id=snap_id, squad=sq, sport=sp, session=sess, window=w))
                snap_id += 1
                # advance the factual trajectory with the coach's chosen intervention
                # (consistency: next window re-uses eff2/eps2, so its latent state equals the PO under a_obs)
                m, n = m_new, n_new
                carry = (eff2, eps2)
                adj = I_MULT[a_obs]
                k_prev = a_obs
                sess_load[idx] += 5 * 10 * I * (1 + 0.5 * m_new)        # sRPE-like AU contribution
        Fit += sess_load * 0.9; Fat += sess_load * 1.0
        acute += sess_load; chronic += sess_load
        last_srpe = sess_load.copy()
    W = pd.DataFrame(wins)
    return ath, W, stream, snaps


def main():
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")
    ath, W, stream, snaps = simulate()
    os.makedirs(f"{out}/raw", exist_ok=True); os.makedirs(f"{out}/processed", exist_ok=True)
    obs_cols = ["athlete_id", "sport", "squad", "position", "sex_male", "age", "training_age", "body_mass",
                "vo2max", "hr_max", "hr_rest"]
    ath[obs_cols].to_csv(f"{out}/raw/athlete_profiles.csv", index=False)
    ath.to_csv(f"{out}/raw/athlete_latent_traits_GROUND_TRUTH.csv", index=False)
    W.to_csv(f"{out}/raw/window_labels_interventions.csv", index=False)
    # long-format sensor stream
    rows = []
    for sid, idx, X in stream:
        for j, a in enumerate(idx):
            for e in range(T):
                rows.append([sid, int(a), e] + list(np.round(X[j, e], 4)))
    S = pd.DataFrame(rows, columns=["snap_id", "athlete_id", "epoch"] + CH)
    S.to_csv(f"{out}/raw/sensor_stream_15s_epochs.csv.gz", index=False, compression="gzip")
    S.head(2000).to_csv(f"{out}/raw/sensor_stream_SAMPLE_first2000rows.csv", index=False)
    # processed tensors: X [n_snap, N, T, C]
    Xall = np.stack([X for _, _, X in stream]).astype(np.float32)
    aidx = np.stack([idx for _, idx, _ in stream])
    np.savez_compressed(f"{out}/processed/cs_perform_tensors.npz", X=Xall, athlete_idx=aidx)
    meta = dict(channels=CH, sports=SPORTS, states=STATES, interventions=INTERV, N_per_squad=N_PER_SQUAD,
                n_sessions=N_SESS, n_windows=N_WIN, T=T, epoch_s=15, seed=SEED,
                n_athletes=int(len(ath)), n_snapshots=int(len(stream)), n_athlete_windows=int(len(W)))
    json.dump(meta, open(f"{out}/processed/meta.json", "w"), indent=2)
    print(json.dumps(meta, indent=1))
    print("state dist", W.state.value_counts(normalize=True).sort_index().round(3).to_dict())
    print("action dist", W.action_obs.value_counts(normalize=True).sort_index().round(3).to_dict())
    best = W[[f"Q_{k}" for k in range(5)]].values.argmax(1)
    print("optimal-action dist", np.bincount(best, minlength=5) / len(best))
    print("coach policy optimal-rate", (best == W.action_obs.values).mean())
    print(pd.crosstab(W.state, best, normalize="index").round(2))
    print("NaN rate", np.isnan(Xall).mean())


if __name__ == "__main__":
    main()
