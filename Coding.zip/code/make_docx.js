// make_docx.js -- renders paper_content.json (blocks) into a journal-style .docx manuscript
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, AlignmentType, WidthType,
  BorderStyle, ShadingType, LevelFormat, TabStopType, HeadingLevel, PageNumber, Footer, Header, VerticalAlign,
} = require("docx");

const [, , inJson, outDocx, figDir] = process.argv;
const C = JSON.parse(fs.readFileSync(inJson, "utf8"));
const FONT = "Times New Roman";
const PAGE_W = 11906, MARGIN = 1134, TEXT_W = PAGE_W - 2 * MARGIN; // A4, 2 cm margins

function runs(text, opts = {}) {
  // **bold** inline markup
  const out = [];
  const parts = String(text).split(/(\*\*[^*]+\*\*)/g);
  for (const p of parts) {
    if (!p) continue;
    if (p.startsWith("**") && p.endsWith("**")) out.push(new TextRun({ text: p.slice(2, -2), bold: true, font: FONT, size: opts.size || 22, italics: opts.italics }));
    else out.push(new TextRun({ text: p, font: FONT, size: opts.size || 22, italics: opts.italics, bold: opts.bold }));
  }
  return out;
}

function pngSize(file) {
  const b = fs.readFileSync(file);
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
}

let figN = 0;
const children = [];
const thin = { style: BorderStyle.SINGLE, size: 4, color: "808080" };
const none = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };

for (const b of C.blocks) {
  switch (b.type) {
    case "title":
      children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 160 }, children: [new TextRun({ text: b.text, bold: true, font: FONT, size: 32 })] }));
      break;
    case "authors":
      children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: runs(b.text, { size: 22 }) }));
      break;
    case "affil":
      children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 240 }, children: runs(b.text, { size: 18, italics: true }) }));
      break;
    case "h1":
      children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text: b.text, font: FONT, bold: true, size: 26 })] }));
      break;
    case "h2":
      children.push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text: b.text, font: FONT, bold: true, italics: true, size: 23 })] }));
      break;
    case "h3":
      children.push(new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun({ text: b.text, font: FONT, italics: true, size: 22 })] }));
      break;
    case "p":
      children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 120, line: 276 }, children: runs(b.text) }));
      break;
    case "eq":
      children.push(new Paragraph({
        tabStops: [{ type: TabStopType.CENTER, position: Math.round(TEXT_W / 2) }, { type: TabStopType.RIGHT, position: TEXT_W }],
        spacing: { before: 60, after: b.num === null || b.num === undefined ? 0 : 120 },
        children: [new TextRun({ text: "\t", font: FONT }), new TextRun({ text: b.text, font: "Cambria Math", size: 20 }),
                   new TextRun({ text: b.num === null || b.num === undefined ? "" : `\t(${b.num})`, font: FONT, size: 22 })],
      }));
      break;
    case "bullets":
      for (const it of b.items) children.push(new Paragraph({ numbering: { reference: "bul", level: 0 }, alignment: AlignmentType.JUSTIFIED, spacing: { after: 60, line: 276 }, children: runs(it) }));
      break;
    case "numbered":
      for (const it of b.items) children.push(new Paragraph({ numbering: { reference: "num", level: 0 }, alignment: AlignmentType.JUSTIFIED, spacing: { after: 60, line: 276 }, children: runs(it) }));
      break;
    case "fig": {
      const f = path.join(figDir, b.path);
      if (!fs.existsSync(f)) { children.push(new Paragraph({ children: runs(`[missing figure ${b.path}]`) })); break; }
      const { w, h } = pngSize(f);
      const wIn = Math.min(b.width || 6.5, TEXT_W / 1440);
      const wPx = Math.round(wIn * 96), hPx = Math.round(wPx * h / w);
      children.push(new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 60 },
        children: [new ImageRun({ type: "png", data: fs.readFileSync(f), transformation: { width: wPx, height: hPx },
                                  altText: { title: b.path, description: b.caption.slice(0, 120), name: b.path } })] }));
      const m = b.caption.match(/^(Figure \d+\.)(.*)$/s);
      children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 200 },
        children: m ? [new TextRun({ text: m[1], bold: true, font: FONT, size: 19 }), ...runs(m[2], { size: 19 })] : runs(b.caption, { size: 19 }) }));
      break;
    }
    case "table": {
      const ncol = b.header.length;
      let widths = b.widths ? b.widths.map((x) => Math.round(x * 1440)) : Array(ncol).fill(Math.floor(TEXT_W / ncol));
      const tot = widths.reduce((a, x) => a + x, 0);
      widths = widths.map((x) => Math.floor(x * TEXT_W / tot));
      const fsz = Math.round((b.fs || 8) * 2);
      const mk = (txt, i, header, last) => new TableCell({
        width: { size: widths[i], type: WidthType.DXA },
        borders: { top: header ? thin : none, bottom: header || last ? thin : none, left: none, right: none },
        shading: header ? { fill: "E8EEF7", type: ShadingType.CLEAR, color: "auto" } : undefined,
        margins: { top: 30, bottom: 30, left: 60, right: 60 }, verticalAlign: VerticalAlign.CENTER,
        children: [new Paragraph({ alignment: (i === 0 || b.align === "left") ? AlignmentType.LEFT : AlignmentType.CENTER,
                                   children: runs(String(txt), { size: fsz, bold: header }) })],
      });
      const m = b.caption.match(/^((?:Table|Algorithm) \d+\.)(.*)$/s);
      children.push(new Paragraph({ keepNext: true, spacing: { before: 160, after: 60 }, alignment: AlignmentType.JUSTIFIED,
        children: m ? [new TextRun({ text: m[1], bold: true, font: FONT, size: 19 }), ...runs(m[2], { size: 19 })] : runs(b.caption, { size: 19 }) }));
      const rows = [new TableRow({ tableHeader: true, children: b.header.map((t, i) => mk(t, i, true, false)) })];
      b.rows.forEach((r, ri) => rows.push(new TableRow({ cantSplit: true, children: r.map((t, i) => mk(t, i, false, ri === b.rows.length - 1)) })));
      children.push(new Table({ width: { size: TEXT_W, type: WidthType.DXA }, columnWidths: widths, rows }));
      if (b.note) children.push(new Paragraph({ spacing: { before: 40, after: 200 }, alignment: AlignmentType.JUSTIFIED, children: runs(b.note, { size: 16, italics: true }) }));
      else children.push(new Paragraph({ spacing: { after: 120 }, children: [] }));
      break;
    }
    case "refs":
      b.items.forEach((t, i) => children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 60 },
        indent: { left: 440, hanging: 440 }, children: runs(`${i + 1}.\t${t}`, { size: 19 }),
        tabStops: [{ type: TabStopType.LEFT, position: 440 }] })));
      break;
    case "pagebreak":
      children.push(new Paragraph({ pageBreakBefore: true, children: [] }));
      break;
  }
}

const doc = new Document({
  creator: "SPRINT authors", title: C.title || "Manuscript",
  styles: {
    default: { document: { run: { font: FONT, size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 26, bold: true },
        paragraph: { spacing: { before: 280, after: 120 }, keepNext: true, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 23, bold: true, italics: true },
        paragraph: { spacing: { before: 200, after: 100 }, keepNext: true, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 22, italics: true },
        paragraph: { spacing: { before: 160, after: 80 }, keepNext: true, outlineLevel: 2 } },
    ],
  },
  numbering: { config: [
    { reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] },
    { reference: "num", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "(%1)", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 400 } } } }] },
  ] },
  sections: [{
    properties: { page: { size: { width: PAGE_W, height: 16838 }, margin: { top: 1134, bottom: 1134, left: MARGIN, right: MARGIN } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "Real-time performance analysis for customised coaching (SPRINT / CLEAR-GWO)", font: FONT, size: 16, italics: true, color: "666666" })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 18 })] })] }) },
    children,
  }],
});
Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(outDocx, buf); console.log("written", outDocx); });
