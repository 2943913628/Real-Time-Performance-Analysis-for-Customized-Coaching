import numpy as np, autograd as ag
from autograd import *
rng=np.random.default_rng(1)
X=Tensor(rng.normal(size=(3,4,5,6)))
L1=Linear(6,8,rng); L2=Linear(8,3,rng); ln=LayerNorm(8)
A=Param(rng.normal(size=(5,5)))
y=rng.integers(0,3,size=12); t=rng.normal(size=(12,))
def fn():
    h=gelu(L1(X))                       # [3,4,5,8]
    h=ln(h)
    att=softmax(A,axis=-1, mask=(np.eye(5)+rng.random((5,5))>-1))
    h=matmul(att,h)                     # broadcast matmul
    q=h[:, :, 1:, :]; q=concat([q, h[:, :, :1, :]],axis=2)
    h=tanh(q)*sigmoid(h)+ h/(2.0+exp(h*0.1))
    s=softmax(matmul(h, swap_last(h))/3.0, axis=-1)
    h=matmul(s,h).mean(axis=2)          # [3,4,8]
    lo=L2(h).reshape(12,3)
    return cross_entropy(lo,y,smoothing=0.1)+mse(lo[:,0],t)+ (relu(lo)*lo).mean()
print("worst rel err:", gradcheck(fn, [L1.W,L1.b,L2.W,ln.g,A], n=8))
