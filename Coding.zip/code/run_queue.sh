#!/bin/bash
cd /home/claude/EI0519-2/code
ls jobs/job_*.sh | sort | xargs -P 2 -I{} bash -c 'bash {}; echo "$(date +%H:%M:%S) done {}" >> ../results/logs/queue.log'
echo ALLDONE >> ../results/logs/queue.log
