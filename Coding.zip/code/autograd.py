"""
autograd.py -- a compact reverse-mode automatic-differentiation engine on NumPy.

The execution sandbox used for this study has no PyTorch/JAX, so every neural model
(SPRINT and all deep baselines) is built on this engine. It supports broadcasting,
batched matmul, fused softmax / layer-norm / cross-entropy and AdamW.
Correctness is verified by finite-difference gradient checks (see gradcheck()).
"""
import numpy as np

DT = np.float64  # float64 keeps the finite-difference checks exact; set float32 for speed
_GRAD_ENABLED = [True]


class no_grad:
    def __enter__(self):
        self.prev = _GRAD_ENABLED[0]
        _GRAD_ENABLED[0] = False

    def __exit__(self, *a):
        _GRAD_ENABLED[0] = self.prev


def set_dtype(dt):
    global DT
    DT = dt


def _unbroadcast(g, shape):
    if g.shape == shape:
        return g
    nd = g.ndim - len(shape)
    if nd > 0:
        g = g.sum(axis=tuple(range(nd)))
    axes = tuple(i for i, s in enumerate(shape) if s == 1 and g.shape[i] != 1)
    if axes:
        g = g.sum(axis=axes, keepdims=True)
    return g.reshape(shape)


class Tensor:
    __slots__ = ("data", "grad", "_prev", "_back", "requires_grad")

    def __init__(self, data, requires_grad=False, _prev=(), _back=None):
        self.data = data if isinstance(data, np.ndarray) and data.dtype == DT else np.asarray(data, dtype=DT)
        self.grad = None
        self.requires_grad = requires_grad
        self._prev = _prev
        self._back = _back

    # ---------- utilities ----------
    @property
    def shape(self):
        return self.data.shape

    @property
    def ndim(self):
        return self.data.ndim

    def numpy(self):
        return self.data

    def __repr__(self):
        return f"Tensor(shape={self.data.shape})"

    def _acc(self, g):
        if self.grad is None:
            self.grad = g
        else:
            self.grad = self.grad + g

    def backward(self, grad=None):
        topo, seen, stack = [], set(), [(self, False)]
        while stack:
            node, done = stack.pop()
            if done:
                topo.append(node)
                continue
            if id(node) in seen:
                continue
            seen.add(id(node))
            stack.append((node, True))
            for p in node._prev:
                if id(p) not in seen:
                    stack.append((p, False))
        self.grad = np.ones_like(self.data) if grad is None else grad
        for node in reversed(topo):
            if node._back is not None and node.grad is not None:
                node._back(node.grad)
                if node._prev:  # free intermediate grads
                    node._back = None

    # ---------- operator overloading ----------
    def __add__(self, o):
        return add(self, o)

    __radd__ = __add__

    def __sub__(self, o):
        return sub(self, o)

    def __rsub__(self, o):
        return sub(as_tensor(o), self)

    def __mul__(self, o):
        return mul(self, o)

    __rmul__ = __mul__

    def __truediv__(self, o):
        return div(self, o)

    def __neg__(self):
        return mul(self, -1.0)

    def __matmul__(self, o):
        return matmul(self, o)

    def __getitem__(self, idx):
        return getitem(self, idx)

    def sum(self, axis=None, keepdims=False):
        return tsum(self, axis, keepdims)

    def mean(self, axis=None, keepdims=False):
        return tmean(self, axis, keepdims)

    def reshape(self, *shape):
        return reshape(self, shape[0] if len(shape) == 1 and isinstance(shape[0], tuple) else shape)

    def transpose(self, *axes):
        return transpose(self, axes)


def as_tensor(x):
    return x if isinstance(x, Tensor) else Tensor(np.asarray(x, dtype=DT))


def _mk(data, parents, back):
    req = _GRAD_ENABLED[0] and any(p.requires_grad for p in parents)
    if not req:
        return Tensor(data)
    return Tensor(data, True, tuple(p for p in parents if p.requires_grad), back)


def Param(arr):
    return Tensor(np.asarray(arr, dtype=DT), requires_grad=True)


# ---------------- elementwise ----------------
def add(a, b):
    a, b = as_tensor(a), as_tensor(b)
    out = a.data + b.data

    def back(g):
        if a.requires_grad: a._acc(_unbroadcast(g, a.shape))
        if b.requires_grad: b._acc(_unbroadcast(g, b.shape))
    return _mk(out, (a, b), back)


def sub(a, b):
    a, b = as_tensor(a), as_tensor(b)
    out = a.data - b.data

    def back(g):
        if a.requires_grad: a._acc(_unbroadcast(g, a.shape))
        if b.requires_grad: b._acc(_unbroadcast(-g, b.shape))
    return _mk(out, (a, b), back)


def mul(a, b):
    a, b = as_tensor(a), as_tensor(b)
    out = a.data * b.data

    def back(g):
        if a.requires_grad: a._acc(_unbroadcast(g * b.data, a.shape))
        if b.requires_grad: b._acc(_unbroadcast(g * a.data, b.shape))
    return _mk(out, (a, b), back)


def div(a, b):
    a, b = as_tensor(a), as_tensor(b)
    out = a.data / b.data

    def back(g):
        if a.requires_grad: a._acc(_unbroadcast(g / b.data, a.shape))
        if b.requires_grad: b._acc(_unbroadcast(-g * a.data / (b.data ** 2), b.shape))
    return _mk(out, (a, b), back)


def tpow(a, p):
    out = a.data ** p

    def back(g):
        a._acc(g * p * a.data ** (p - 1))
    return _mk(out, (a,), back)


def exp(a):
    out = np.exp(a.data)

    def back(g):
        a._acc(g * out)
    return _mk(out, (a,), back)


def log(a, eps=1e-12):
    out = np.log(a.data + eps)

    def back(g):
        a._acc(g / (a.data + eps))
    return _mk(out, (a,), back)


def tanh(a):
    out = np.tanh(a.data)

    def back(g):
        a._acc(g * (1 - out * out))
    return _mk(out, (a,), back)


def sigmoid(a):
    out = 1.0 / (1.0 + np.exp(-np.clip(a.data, -40, 40)))

    def back(g):
        a._acc(g * out * (1 - out))
    return _mk(out, (a,), back)


def relu(a):
    m = a.data > 0
    out = a.data * m

    def back(g):
        a._acc(g * m)
    return _mk(out, (a,), back)


def gelu(a):
    x = a.data
    c = np.sqrt(2 / np.pi)
    x2 = x * x
    u = c * x * (1 + 0.044715 * x2)
    t = np.tanh(u)
    out = 0.5 * x * (1 + t)

    def back(g):
        du = c * (1 + 3 * 0.044715 * x2)
        a._acc(g * (0.5 * (1 + t) + 0.5 * x * (1 - t * t) * du))
    return _mk(out, (a,), back)


# ---------------- reductions / shape ----------------
def tsum(a, axis=None, keepdims=False):
    out = a.data.sum(axis=axis, keepdims=keepdims)

    def back(g):
        if axis is not None and not keepdims:
            g = np.expand_dims(g, axis)
        a._acc(np.broadcast_to(g, a.shape))
    return _mk(out, (a,), back)


def tmean(a, axis=None, keepdims=False):
    n = a.data.size if axis is None else np.prod([a.shape[i] for i in (axis if isinstance(axis, tuple) else (axis,))])
    return mul(tsum(a, axis, keepdims), 1.0 / n)


def reshape(a, shape):
    out = a.data.reshape(shape)

    def back(g):
        a._acc(g.reshape(a.shape))
    return _mk(out, (a,), back)


def transpose(a, axes):
    axes = tuple(axes) if axes else tuple(reversed(range(a.ndim)))
    inv = np.argsort(axes)
    out = a.data.transpose(axes)

    def back(g):
        a._acc(g.transpose(inv))
    return _mk(out, (a,), back)


def swap_last(a):
    ax = list(range(a.ndim))
    ax[-1], ax[-2] = ax[-2], ax[-1]
    return transpose(a, ax)


def _is_basic(idx):
    idx = idx if isinstance(idx, tuple) else (idx,)
    return all(isinstance(i, (slice, int, type(Ellipsis), type(None))) for i in idx)


def getitem(a, idx):
    out = a.data[idx]
    basic = _is_basic(idx)

    def back(g):
        z = np.zeros_like(a.data)
        if basic:
            z[idx] = g
        else:
            np.add.at(z, idx, g)
        a._acc(z)
    return _mk(out, (a,), back)


def concat(ts, axis=-1):
    ts = [as_tensor(t) for t in ts]
    out = np.concatenate([t.data for t in ts], axis=axis)
    sizes = np.cumsum([t.shape[axis] for t in ts])[:-1]

    def back(g):
        parts = np.split(g, sizes, axis=axis)
        for t, p in zip(ts, parts):
            if t.requires_grad:
                t._acc(p)
    return _mk(out, tuple(ts), back)


def stack(ts, axis=0):
    return concat([reshape(t, t.shape[:axis] + (1,) + t.shape[axis:]) if axis >= 0 else
                   reshape(t, t.shape + (1,)) for t in ts], axis=axis)


def matmul(a, b):
    a, b = as_tensor(a), as_tensor(b)
    if b.data.ndim == 2 and a.data.ndim > 2:          # dense layer fast path (single GEMM)
        sh = a.data.shape
        a2 = a.data.reshape(-1, sh[-1])
        out = (a2 @ b.data).reshape(sh[:-1] + (b.data.shape[1],))

        def back2(g):
            g2 = g.reshape(-1, g.shape[-1])
            if a.requires_grad: a._acc((g2 @ b.data.T).reshape(sh))
            if b.requires_grad: b._acc(a2.T @ g2)
        return _mk(out, (a, b), back2)
    out = np.matmul(a.data, b.data)

    def back(g):
        if a.requires_grad:
            a._acc(_unbroadcast(np.matmul(g, np.swapaxes(b.data, -1, -2)), a.shape))
        if b.requires_grad:
            b._acc(_unbroadcast(np.matmul(np.swapaxes(a.data, -1, -2), g), b.shape))
    return _mk(out, (a, b), back)


# ---------------- fused ops ----------------
def softmax(a, axis=-1, mask=None):
    """mask: boolean array broadcastable to a (True = keep)."""
    x = a.data
    if mask is not None:
        x = np.where(mask, x, -1e9)
    x = x - x.max(axis=axis, keepdims=True)
    e = np.exp(x)
    out = e / e.sum(axis=axis, keepdims=True)

    def back(g):
        a._acc(out * (g - (g * out).sum(axis=axis, keepdims=True)))
    return _mk(out, (a,), back)


def layernorm(a, gamma, beta, eps=1e-5):
    x = a.data
    mu = x.mean(-1, keepdims=True)
    var = x.var(-1, keepdims=True)
    inv = 1.0 / np.sqrt(var + eps)
    xh = (x - mu) * inv
    out = xh * gamma.data + beta.data
    D = x.shape[-1]

    def back(g):
        if gamma.requires_grad: gamma._acc(_unbroadcast(g * xh, gamma.shape))
        if beta.requires_grad: beta._acc(_unbroadcast(g, beta.shape))
        if a.requires_grad:
            gx = g * gamma.data
            a._acc(inv / D * (D * gx - gx.sum(-1, keepdims=True) - xh * (gx * xh).sum(-1, keepdims=True)))
    return _mk(out, (a, gamma, beta), back)


def dropout(a, p, rng, train=True):
    if not train or p <= 0:
        return a
    m = (rng.random(a.shape) >= p).astype(DT) / (1 - p)
    return mul(a, Tensor(m))


def cross_entropy(logits, y, weight=None, smoothing=0.0):
    """logits Tensor [n,K]; y int array [n]; weight optional per-sample array [n]."""
    x = logits.data
    n, K = x.shape
    z = x - x.max(1, keepdims=True)
    lse = np.log(np.exp(z).sum(1, keepdims=True))
    logp = z - lse
    t = np.full((n, K), smoothing / K)
    t[np.arange(n), y] += 1 - smoothing
    w = np.ones(n) if weight is None else np.asarray(weight, dtype=DT)
    W = w.sum()
    loss = -(w[:, None] * t * logp).sum() / W
    p = np.exp(logp)

    def back(g):
        logits._acc(g * w[:, None] * (p - t) / W)
    return _mk(np.asarray(loss, dtype=DT), (logits,), back)


def mse(pred, target, weight=None):
    target = np.asarray(target, dtype=DT)
    d = pred.data - target
    w = np.ones_like(d) if weight is None else np.broadcast_to(np.asarray(weight, dtype=DT), d.shape)
    W = w.sum()
    loss = (w * d * d).sum() / W

    def back(g):
        pred._acc(g * 2 * w * d / W)
    return _mk(np.asarray(loss, dtype=DT), (pred,), back)


# ---------------- modules ----------------
class Module:
    def parameters(self):
        out, seen = [], set()

        def walk(o):
            if isinstance(o, Tensor):
                if o.requires_grad and id(o) not in seen:
                    seen.add(id(o)); out.append(o)
            elif isinstance(o, Module):
                for v in o.__dict__.values():
                    walk(v)
            elif isinstance(o, (list, tuple)):
                for v in o:
                    walk(v)
            elif isinstance(o, dict):
                for v in o.values():
                    walk(v)
        walk(self)
        return out

    def n_params(self):
        return int(sum(p.data.size for p in self.parameters()))

    def state_dict(self):
        return [p.data.copy() for p in self.parameters()]

    def load_state_dict(self, sd):
        for p, v in zip(self.parameters(), sd):
            p.data[...] = v


class Linear(Module):
    def __init__(self, din, dout, rng, bias=True):
        lim = np.sqrt(6.0 / (din + dout))
        self.W = Param(rng.uniform(-lim, lim, (din, dout)))
        self.b = Param(np.zeros(dout)) if bias else None

    def __call__(self, x):
        y = matmul(x, self.W)
        return add(y, self.b) if self.b is not None else y


class LayerNorm(Module):
    def __init__(self, d):
        self.g = Param(np.ones(d))
        self.b = Param(np.zeros(d))

    def __call__(self, x):
        return layernorm(x, self.g, self.b)


class AdamW:
    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, wd=1e-4, clip=1.0):
        self.p = params
        self.lr, self.b1, self.b2, self.eps, self.wd, self.clip = lr, betas[0], betas[1], eps, wd, clip
        self.m = [np.zeros_like(q.data) for q in params]
        self.v = [np.zeros_like(q.data) for q in params]
        self.t = 0

    def zero_grad(self):
        for q in self.p:
            q.grad = None

    def step(self, lr=None):
        lr = self.lr if lr is None else lr
        self.t += 1
        gs = [q.grad if q.grad is not None else np.zeros_like(q.data) for q in self.p]
        if self.clip:
            nrm = np.sqrt(sum((g * g).sum() for g in gs))
            if nrm > self.clip:
                gs = [g * (self.clip / (nrm + 1e-12)) for g in gs]
        for i, (q, g) in enumerate(zip(self.p, gs)):
            self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g
            self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * g * g
            mh = self.m[i] / (1 - self.b1 ** self.t)
            vh = self.v[i] / (1 - self.b2 ** self.t)
            if q.data.ndim > 1:
                q.data -= lr * self.wd * q.data
            q.data -= lr * mh / (np.sqrt(vh) + self.eps)


# ---------------- gradient check ----------------
def gradcheck(fn, params, eps=1e-6, n=6, rng=None):
    rng = rng or np.random.default_rng(0)
    for p in params:
        p.grad = None
    loss = fn()
    loss.backward()
    worst = 0.0
    for p in params:
        ana = p.grad.copy()
        for _ in range(n):
            idx = tuple(rng.integers(0, s) for s in p.shape)
            old = p.data[idx]
            p.data[idx] = old + eps
            with no_grad():
                lp = fn().data
            p.data[idx] = old - eps
            with no_grad():
                lm = fn().data
            p.data[idx] = old
            num = (lp - lm) / (2 * eps)
            rel = abs(num - ana[idx]) / max(1e-8, abs(num) + abs(ana[idx]))
            worst = max(worst, rel)
    return worst
