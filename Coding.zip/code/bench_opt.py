"""optimizer comparison on 8 classical benchmark functions (D=30) + CLEAR-GWO component ablation."""
import numpy as np, json, os, time
from functools import partial
import optim
from optim import BENCH, bench_fn
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
D, POP, B, SEEDS = 30, 30, 9000, 10
algs = {k: v for k, v in optim.OPTIMIZERS.items()}
abl = {"CLEAR w/o chaos": dict(use_chaos=False), "CLEAR w/o Levy": dict(use_levy=False),
       "CLEAR w/o elite": dict(use_elite=False), "CLEAR w/o DLH": dict(use_dlh=False),
       "CLEAR w/o weights": dict(use_weights=False), "CLEAR linear a": dict(sched="lin")}
for k, kw in abl.items():
    algs[k] = partial(optim.clear_gwo, **kw)
res = {}
cps = np.linspace(B / 30, B, 30).astype(int)
t0 = time.time()
for fn in BENCH:
    res[fn] = {}
    for an, a in algs.items():
        bests, curves = [], []
        for s in range(SEEDS):
            tr = a(bench_fn(fn, s), D, B, pop=POP, seed=s)
            c = np.array(tr.curve); c = np.concatenate([c, np.full(max(0, B - len(c)), c[-1])])
            bests.append(tr.best); curves.append(c[cps - 1].tolist())
        cv = np.array(curves)
        res[fn][an] = dict(best=bests, mean=float(np.mean(bests)), std=float(np.std(bests)),
                           curve=np.mean(cv, 0).tolist(), curve_geo=(10 ** np.mean(np.log10(cv + 1e-12), 0)).tolist(),
                           curve_median=np.median(cv, 0).tolist())
        print(fn, an, f"{np.mean(bests):.3e}", f"{time.time()-t0:.0f}s", flush=True)
    json.dump(dict(res=res, checkpoints=cps.tolist(), D=D, pop=POP, budget=B, seeds=SEEDS),
              open(f"{OUT}/bench_optimizers.json", "w"))
