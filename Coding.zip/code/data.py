"""data.py -- loading, cleaning, normalisation and chronological splitting of CS-PERFORM."""
import numpy as np, pandas as pd, json, os

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")

# physiological prior graph between the 12 wearable channels (domain knowledge)
CH = ["HR_bpm", "RMSSD_ms", "RespRate_bpm", "SkinTemp_C", "Speed_mps", "AccelLoad_ms2",
      "PlayerLoad_au", "SmO2_pct", "GCT_ms", "StrideFreq_Hz", "Stiffness_idx", "Asymmetry_pct"]
PRIOR_EDGES = [(0, 1), (0, 2), (0, 3), (0, 7), (2, 7), (1, 2),            # cardio-respiratory / metabolic
               (4, 5), (4, 6), (5, 6), (4, 0), (6, 0), (4, 7),            # external <-> internal load
               (4, 9), (4, 8), (8, 9), (8, 10), (8, 11), (10, 11),        # gait / neuromuscular
               (6, 11), (6, 10), (5, 10)]


def prior_adjacency(C=12):
    A = np.eye(C)
    for i, j in PRIOR_EDGES:
        A[i, j] = A[j, i] = 1.0
    return A / A.sum(1, keepdims=True)


class Dataset:
    def __init__(self, root=ROOT, train_sessions=(0, 25), val_sessions=(25, 29), test_sessions=(29, 36)):
        z = np.load(f"{root}/processed/cs_perform_tensors.npz")
        X = z["X"].astype(np.float64)                 # [S,N,T,C] with NaN
        self.meta = json.load(open(f"{root}/processed/meta.json"))
        W = pd.read_csv(f"{root}/raw/window_labels_interventions.csv").sort_values(["snap_id", "slot"])
        ath = pd.read_csv(f"{root}/raw/athlete_profiles.csv").set_index("athlete_id")
        S, N, T, C = X.shape
        self.S, self.N, self.T, self.C = S, N, T, C
        g = lambda c: W[c].values.reshape(S, N)
        self.y = g("state").astype(int); self.pri = g("PRI"); self.a = g("action_obs").astype(int)
        self.q = g("Q_obs"); self.Q = W[[f"Q_{k}" for k in range(5)]].values.reshape(S, N, 5)
        self.prop_true = W[[f"prop_{k}" for k in range(5)]].values.reshape(S, N, 5)
        self.aid = g("athlete_id").astype(int)
        self.session = g("session")[:, 0]; self.window = g("window")[:, 0]; self.squad = g("squad")[:, 0]
        self.sport = np.array([s for s in W.sport.values.reshape(S, N)[:, 0]])
        self.lat = {k: g(k) for k in ["lat_stimulus", "lat_met_fatigue", "lat_nm_fatigue", "lat_tech_degr"]}
        tr = (self.session >= train_sessions[0]) & (self.session < train_sessions[1])
        va = (self.session >= val_sessions[0]) & (self.session < val_sessions[1])
        te = (self.session >= test_sessions[0]) & (self.session < test_sessions[1])
        self.split = dict(train=np.where(tr)[0], val=np.where(va)[0], test=np.where(te)[0])
        # ---- cleaning: forward-fill within window, then channel mean (train) ----
        self.miss_mask = np.isnan(X)
        Xf = X.copy()
        for t in range(1, T):
            m = np.isnan(Xf[:, :, t]); Xf[:, :, t][m] = Xf[:, :, t - 1][m]
        for t in range(T - 2, -1, -1):
            m = np.isnan(Xf[:, :, t]); Xf[:, :, t][m] = Xf[:, :, t + 1][m]
        mu = np.nanmean(Xf[tr], axis=(0, 1, 2)); sd = np.nanstd(Xf[tr], axis=(0, 1, 2)) + 1e-6
        Xf = np.where(np.isnan(Xf), mu, Xf)
        self.raw_X = Xf
        self.X = (Xf - mu) / sd
        self.ch_mu, self.ch_sd = mu, sd
        # ---- static / contextual profile ----
        a = ath.loc[self.aid.ravel()]
        sport_oh = pd.get_dummies(a.sport).reindex(columns=self.meta["sports"], fill_value=0).values.astype(float)
        pos_oh = np.eye(3)[a.position.values]
        num = np.column_stack([a.age, a.training_age, a.body_mass, a.vo2max, a.hr_max, a.hr_rest,
                               W.sleep_h, W.wellness, W.acwr, W.prev_srpe, W.days_since])
        trr = np.repeat(tr, N)
        num = (num - num[trr].mean(0)) / (num[trr].std(0) + 1e-6)
        # session plan known to the coach: planned drill intensity of current and next window
        plan = W.planned_intensity.values.reshape(S, N)
        nxt = np.zeros_like(plan)
        for i in range(S):
            j = i + 1
            nxt[i] = plan[j] if (j < S and self.session[j] == self.session[i] and self.squad[j] == self.squad[i]) else plan[i] * 0.9
        # longitudinal personal response memory (strictly from previous sessions; causal)
        resp = self._response_memory(W, S, N)
        stat = np.column_stack([sport_oh, pos_oh, a.sex_male.values, num, W.window.values / 5.0,
                                plan.ravel(), nxt.ravel(), resp])
        self.Sx = stat.reshape(S, N, -1)
        self.P = self.Sx.shape[-1]
        self.pos = a.position.values.reshape(S, N)
        self.pri_mu, self.pri_sd = self.pri[tr].mean(), self.pri[tr].std()
        self.q_mu, self.q_sd = self.q[tr].mean(), self.q[tr].std()
        self.A_prior = prior_adjacency(C)
        self.class_w = 1.0 / np.sqrt(np.bincount(self.y[tr].ravel(), minlength=4) / self.y[tr].size)
        self.class_w /= self.class_w.mean()

    def _response_memory(self, W, S, N, prior=4.0):
        q = W.Q_obs.values.reshape(S, N); res = q - q.mean(1, keepdims=True)
        a = W.action_obs.values.reshape(S, N); y = W.state.values.reshape(S, N); pri = W.PRI.values.reshape(S, N)
        aid = W.athlete_id.values.reshape(S, N)
        n_ath = aid.max() + 1
        sumr = np.zeros((n_ath, 5)); cnt = np.zeros((n_ath, 5)); sc = np.zeros((n_ath, 4)); sp = np.zeros(n_ath); ns = np.zeros(n_ath)
        out = np.zeros((S, N, 5 + 4 + 1))
        order = np.lexsort((self.window, self.session))
        cur_sess = -1; pending = []
        for i in order:
            if self.session[i] != cur_sess:              # commit previous session's windows
                for (ii, jj) in pending:
                    k, u = a[ii, jj], aid[ii, jj]
                    sumr[u, k] += res[ii, jj]; cnt[u, k] += 1; sc[u, y[ii, jj]] += 1; sp[u] += pri[ii, jj]; ns[u] += 1
                pending, cur_sess = [], self.session[i]
            for j in range(N):
                u = aid[i, j]
                out[i, j, :5] = sumr[u] / (cnt[u] + prior) / 5.0
                out[i, j, 5:9] = (sc[u] + 1) / (ns[u] + 4)
                out[i, j, 9] = (sp[u] / max(ns[u], 1) - 50) / 25 if ns[u] > 0 else 0.0
                pending.append((i, j))
        return out.reshape(S * N, -1)

    def batch(self, idx):
        return dict(X=self.X[idx], S=self.Sx[idx], pos=self.pos[idx], y=self.y[idx], pri=self.pri[idx],
                    a=self.a[idx], q=self.q[idx], Q=self.Q[idx])

    def handcrafted(self, idx):
        """per athlete-window summary features for classical ML baselines."""
        X = self.X[idx]                                    # [B,N,T,C]
        t = np.arange(self.T) - (self.T - 1) / 2
        slope = (X * t[None, None, :, None]).sum(2) / (t ** 2).sum()
        f = np.concatenate([X.mean(2), X.std(2), X[:, :, -1], X[:, :, -5:].mean(2) - X[:, :, :5].mean(2),
                            X.min(2), X.max(2), slope, self.Sx[idx]], -1)
        return f.reshape(-1, f.shape[-1])
