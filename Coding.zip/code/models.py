"""
models.py -- SPRINT and deep baselines, all on the NumPy autodiff engine.

SPRINT = Sensor-Peer Relational INtervention-aware Temporal graph network
  (1) per-channel patch tokenisation of the 12 wearable streams
  (2) Multi-Scale Gated Temporal Attention (MS-GTA): parallel dilated causal gated convolutions
      fused by node-wise scale attention
  (3) Tri-Adjacency Gated Sensor Graph (TAG): physiological-prior + learnable adaptive +
      window-specific dynamic attention adjacencies, mixed by a profile-conditioned gate
  (4) recency-biased temporal attention pooling + channel read-out attention (interpretable)
  (5) profile-conditioned FiLM personalisation
  (6) Peer Cohort Graph Attention (PCGA): dynamic k-NN + same-position graph across the athletes
      of a squad in the same training window, with peer-referenced deviation features
  (7) multi-task heads: performance state, PRI, propensity and K intervention-conditioned
      counterfactual outcome heads (for safety-constrained customised coaching recommendations)
"""
import numpy as np
import autograd as ag
from autograd import (Tensor, Param, Linear, LayerNorm, Module, matmul, softmax, gelu, tanh, sigmoid,
                      concat, swap_last, dropout, relu)


def const(x):
    return Tensor(np.asarray(x, dtype=ag.DT))


def shift_time(H, delta):
    """causal shift along axis 1 (zero padding at the start)."""
    if delta == 0:
        return H
    T = H.shape[1]
    if delta >= T:
        return const(np.zeros(H.shape))
    pad = const(np.zeros((H.shape[0], delta) + H.shape[2:]))
    return concat([pad, H[:, :T - delta]], axis=1)


class GatedTCN(Module):
    def __init__(self, d, dil, rng, k=2):
        self.dil, self.k = dil, k
        self.lin = Linear(k * d, 2 * d, rng)
        self.out = Linear(d, d, rng)
        self.ln = LayerNorm(d)

    def __call__(self, H):
        d = H.shape[-1]
        xs = [shift_time(H, i * self.dil) for i in range(self.k)]
        u = self.lin(concat(xs, axis=-1) if self.k > 1 else xs[0])
        g = tanh(u[..., :d]) * sigmoid(u[..., d:])
        return self.ln(H + self.out(g))


class MSGTA(Module):
    """Multi-Scale Gated Temporal Attention."""

    def __init__(self, d, rng, dils=(1, 2, 4), scale_att=True):
        self.br = [GatedTCN(d, dl, rng) for dl in dils]
        self.scale_att = scale_att and len(dils) > 1
        self.att = Linear(d, d, rng)
        self.v = Param(rng.normal(0, 0.1, (d, 1)))
        self.last_alpha = None

    def __call__(self, H):
        outs = [b(H) for b in self.br]
        if len(outs) == 1:
            return outs[0]
        if not self.scale_att:
            o = outs[0]
            for x in outs[1:]:
                o = o + x
            return o * (1.0 / len(outs))
        sc = [matmul(tanh(self.att(o.mean(axis=1))), self.v) for o in outs]      # [M,C,1]
        a = softmax(concat(sc, axis=-1), axis=-1)                                  # [M,C,S]
        self.last_alpha = a.data
        M, C = a.shape[0], a.shape[1]
        out = None
        for i, o in enumerate(outs):
            w = a[:, :, i:i + 1].reshape(M, 1, C, 1)
            out = o * w if out is None else out + o * w
        return out


class TriGraph(Module):
    """Tri-Adjacency Gated sensor graph (prior / adaptive / dynamic)."""

    def __init__(self, C, d, P, rng, A_prior, use=(1, 1, 1), gate=True, emb=8):
        self.use, self.gate_on = use, gate
        self.Ap = np.asarray(A_prior)
        self.E1 = Param(rng.normal(0, 0.4, (C, emb))); self.E2 = Param(rng.normal(0, 0.4, (C, emb)))
        self.q = Linear(d, d, rng, bias=False); self.k = Linear(d, d, rng, bias=False)
        self.g = Linear(d + P, 3, rng)
        self.W = Linear(d, d, rng)
        self.ln = LayerNorm(d)
        self.last_A, self.last_gate = None, None

    def adjacency(self, H, S):
        M, C, d = H.shape[0], H.shape[2], H.shape[3]
        hs = H.mean(axis=1)                                                       # [M,C,d]
        comps = []
        if self.use[0]:
            comps.append(const(self.Ap.reshape(1, C, C)))
        if self.use[1]:
            comps.append(softmax(relu(matmul(self.E1, swap_last(self.E2))), axis=-1).reshape(1, C, C))
        if self.use[2]:
            comps.append(softmax(matmul(self.q(hs), swap_last(self.k(hs))) * (1.0 / np.sqrt(d)), axis=-1))
        if len(comps) == 1:
            A = comps[0]
        elif self.gate_on:
            gl = self.g(concat([hs.mean(axis=1), S], axis=-1))                    # [M,3]
            idx = [i for i in range(3) if self.use[i]]
            gate = softmax(gl[:, idx], axis=-1)
            self.last_gate = gate.data
            A = None
            for j, cmp in enumerate(comps):
                t = cmp * gate[:, j:j + 1].reshape(M, 1, 1)
                A = t if A is None else A + t
        else:
            A = comps[0]
            for cmp in comps[1:]:
                A = A + cmp
            A = A * (1.0 / len(comps))
        return A

    def __call__(self, H, S):
        M, C = H.shape[0], H.shape[2]
        A = self.adjacency(H, S)
        if A.shape[0] == 1:
            A = A.reshape(1, 1, C, C)
        else:
            A = A.reshape(M, 1, C, C)
        self.last_A = A.data
        Hn = matmul(A, H)
        return self.ln(H + gelu(self.W(Hn)))


class RecencyPool(Module):
    """recency-biased temporal attention pooling (query = most recent token)."""

    def __init__(self, d, rng, recency=True):
        self.q = Linear(d, d, rng, bias=False); self.k = Linear(d, d, rng, bias=False)
        self.beta = Param(np.array([1.0]))
        self.recency = recency

    def __call__(self, H):                       # H [M,T,C,d] -> [M,C,d]
        M, T, C, d = H.shape
        if not self.recency:
            return H.mean(axis=1)
        q = self.q(H[:, T - 1]).reshape(M, 1, C, d)
        sc = (self.k(H) * q).sum(axis=-1) * (1.0 / np.sqrt(d))                    # [M,T,C]
        pos = const(((np.arange(T) - (T - 1)) / T).reshape(1, T, 1))
        sc = sc + self.beta * pos
        a = softmax(sc, axis=1)
        return (H * a.reshape(M, T, C, 1)).sum(axis=1)


class ChannelReadout(Module):
    """identity-preserving read-out: attention pooling (interpretable sensor weights) + flattened projection."""

    def __init__(self, d, rng, C=12, flat=True):
        self.W = Linear(d, d, rng); self.v = Param(rng.normal(0, 0.1, (d, 1)))
        self.F = Linear(C * d, d, rng) if flat else None
        self.last = None

    def __call__(self, Hc):                      # [M,C,d] -> [M,d]
        a = softmax(matmul(tanh(self.W(Hc)), self.v), axis=1)                    # [M,C,1]
        self.last = a.data[..., 0]
        z = (Hc * a).sum(axis=1)
        if self.F is not None:
            M, C, d = Hc.shape
            z = z + gelu(self.F(Hc.reshape(M, C * d)))
        return z


class FiLM(Module):
    def __init__(self, P, d, rng):
        self.h = Linear(P, d, rng); self.g = Linear(d, d, rng); self.b = Linear(d, d, rng)

    def __call__(self, z, S):
        u = gelu(self.h(S))
        return z * (tanh(self.g(u)) + 1.0) + self.b(u)


class PeerGAT(Module):
    """Peer Cohort Graph Attention over the athletes of one squad-window snapshot."""

    def __init__(self, d, rng, heads=2, k=4, use_pos=True):
        self.h, self.kn, self.use_pos = heads, k, use_pos
        self.Q = Linear(d, d, rng, bias=False); self.K = Linear(d, d, rng, bias=False)
        self.V = Linear(d, d, rng, bias=False); self.O = Linear(d, d, rng)
        self.ln = LayerNorm(d)
        self.last_att = None

    def mask(self, z, pos):
        B, N, d = z.shape
        zn = z / (np.linalg.norm(z, axis=-1, keepdims=True) + 1e-8)
        sim = zn @ zn.transpose(0, 2, 1)
        k = min(self.kn, N)
        thr = np.sort(sim, axis=-1)[:, :, -k][:, :, None]
        m = sim >= thr
        if self.use_pos:
            m |= (pos[:, :, None] == pos[:, None, :])
        m |= np.eye(N, dtype=bool)[None]
        return m

    def __call__(self, z, pos):                  # z [B,N,d]
        B, N, d = z.shape
        h, dh = self.h, d // self.h
        m = self.mask(z.data, pos)[:, None]                                        # [B,1,N,N]
        sp = lambda t: t.reshape(B, N, h, dh).transpose(0, 2, 1, 3)
        q, k, v = sp(self.Q(z)), sp(self.K(z)), sp(self.V(z))
        a = softmax(matmul(q, swap_last(k)) * (1.0 / np.sqrt(dh)), axis=-1, mask=m)
        self.last_att = a.data
        o = matmul(a, v).transpose(0, 2, 1, 3).reshape(B, N, d)
        return self.ln(z + self.O(o))


class Heads(Module):
    def __init__(self, din, d, rng, K=5, ns=4):
        self.trunk = Linear(din, d, rng); self.ln = LayerNorm(d)
        self.cls = Linear(d, ns, rng); self.reg = Linear(d, 1, rng); self.prop = Linear(d, K, rng)
        self.ie = Param(rng.normal(0, 0.5, (K, d)))
        self.o1 = Linear(d, d, rng); self.o2 = Linear(d, 1, rng)
        self.K = K

    def __call__(self, h, p, rng, train):
        M = h.shape[0]
        u = dropout(gelu(self.ln(self.trunk(h))), p, rng, train)
        d = u.shape[-1]
        hu = self.o1(u).reshape(M, 1, d) + self.ie
        mu = self.o2(gelu(hu)).reshape(M, self.K)
        return dict(logits=self.cls(u), pri=self.reg(u).reshape(M), mu=mu, prop=self.prop(u), emb=u)


class CIMHeads(Module):
    """Counterfactual Intervention Module: state-conditioned intervention-specific outcome towers
    (TARNet-style) on a shared representation + propensity head (used for IPW and as regulariser)."""

    def __init__(self, din, d, rng, K=5, ns=4):
        self.trunk = Linear(din, d, rng); self.ln = LayerNorm(d)
        self.cls = Linear(d, ns, rng); self.reg = Linear(d, 1, rng); self.prop = Linear(d, K, rng)
        lim1 = np.sqrt(6 / (2 * d + ns)); lim2 = np.sqrt(6 / (d + 1))
        self.W1 = Param(rng.uniform(-lim1, lim1, (K, d + ns, d))); self.b1 = Param(np.zeros((K, 1, d)))
        self.W2 = Param(rng.uniform(-lim2, lim2, (K, d, 1))); self.b2 = Param(np.zeros((K, 1, 1)))
        self.K = K

    def __call__(self, h, p, rng, train):
        M = h.shape[0]
        u = dropout(gelu(self.ln(self.trunk(h))), p, rng, train)
        logits = self.cls(u)
        ps = const(np.exp(logits.data - logits.data.max(1, keepdims=True)))
        ps = const(ps.data / ps.data.sum(1, keepdims=True))                 # stop-gradient state belief
        u2 = concat([u, ps], axis=-1).reshape(1, M, -1)
        hid = gelu(matmul(u2, self.W1) + self.b1)                           # [K,M,d]
        mu = (matmul(hid, self.W2) + self.b2).reshape(self.K, M).transpose(1, 0)
        return dict(logits=logits, pri=self.reg(u).reshape(M), mu=mu, prop=self.prop(u), emb=u)


# =====================================================================================
class SPRINT(Module):
    name = "SPRINT"

    def __init__(self, C, T, P, A_prior, cfg, seed=0):
        rng = np.random.default_rng(seed)
        self.rng = rng
        self.cfg = cfg
        d, self.patch = int(cfg.get("d", 32)), int(cfg.get("patch", 4))
        self.Tp = T // self.patch
        f = cfg.get("flags", {})
        self.f = f
        self.Wc = Param(rng.normal(0, 1 / np.sqrt(self.patch), (C, self.patch, d)))
        self.bc = Param(rng.normal(0, 0.1, (C, d)))
        self.tpos = Param(rng.normal(0, 0.05, (self.Tp, 1, d)))
        dils = tuple(cfg.get("dils", (1, 2))) if f.get("msgta", True) else (1,)
        use = (f.get("prior", 1), f.get("adaptive", 1), f.get("dynamic", 1))
        self.blocks = [(MSGTA(d, rng, dils, scale_att=f.get("scale_att", True)),
                        TriGraph(C, d, P, rng, A_prior, use=use, gate=f.get("gate", True)) if f.get("graph", True) else None)
                       for _ in range(int(cfg.get("L", 2)))]
        self.pool = RecencyPool(d, rng, recency=f.get("recency", True))
        # physiological descriptor branch: per-channel statistical descriptors -> node tokens
        self.desc = Linear(7, d, rng) if f.get("desc", True) else None
        self.post = TriGraph(C, d, P, rng, A_prior, use=use, gate=f.get("gate", True)) \
            if (f.get("desc", True) and f.get("graph", True)) else None
        self.readout = ChannelReadout(d, rng, C=C, flat=f.get("flat", True))
        # dense cross-channel sequence stream (complements the channel-graph stream) + gated stream fusion
        self.seq_on, self.graph_on = f.get("seq", False), f.get("graph_stream", True)
        if self.seq_on:
            self.s_in = Linear(C, 4 * d, rng); self.s_rec = Linear(d, 4 * d, rng, bias=False)
            self.fuse = Linear(2 * d, d, rng)
        self.last_fuse = None
        self.film = FiLM(P, d, rng) if f.get("film", True) else None
        self.sproj = Linear(d + P, d, rng) if not f.get("film", True) else None
        self.peer = PeerGAT(d, rng, heads=int(cfg.get("heads", 2)), k=int(cfg.get("k_peer", 4))) if f.get("peer", True) else None
        HeadCls = CIMHeads if f.get("cim", True) else Heads
        self.ctx_skip = f.get("ctx_skip", True)          # context skip connection into the trunk
        din = (2 * d if self.peer is not None else d) + (P if self.ctx_skip else 0)
        self.heads = HeadCls(din, d, rng)

    def seq_stream(self, X):
        M, T, C = X.shape
        d = self.s_rec.W.shape[0]
        xin = self.s_in(const(X))
        h = const(np.zeros((M, d))); c_ = const(np.zeros((M, d)))
        for t in range(T):
            g = xin[:, t] + self.s_rec(h)
            i, fg, o, u = sigmoid(g[:, :d]), sigmoid(g[:, d:2 * d] + 1.0), sigmoid(g[:, 2 * d:3 * d]), tanh(g[:, 3 * d:])
            c_ = fg * c_ + i * u
            h = o * tanh(c_)
        return h

    def encode(self, X, S):
        """X [M,T,C] (numpy), S [M,P] -> per-athlete embedding [M,d]"""
        if not self.graph_on:
            z = self.seq_stream(X)
            St = const(S)
            return self.film(z, St) if self.film is not None else gelu(self.sproj(concat([z, St], axis=-1)))
        M, T, C = X.shape
        p = self.patch
        Tp = max(1, T // p)
        Xd = X
        X = X[:, T - Tp * p:]
        Xp = X.reshape(M, Tp, p, C).transpose(0, 1, 3, 2).reshape(M, Tp, C, 1, p)
        tpos = self.tpos if Tp == self.Tp else self.tpos[self.Tp - Tp:]
        H = matmul(const(Xp), self.Wc).reshape(M, Tp, C, -1) + self.bc + tpos
        St = const(S)
        for tb, gb in self.blocks:
            H = tb(H)
            if gb is not None:
                H = gb(H, St)
        Hc = dropout(self.pool(H), float(self.cfg.get("enc_dropout", 0.1)), self.rng, self._train)   # [M,C,d]
        if self.desc is not None:
            Xr = Xd                                                               # [M,T,C] full window (normalised)
            t = np.arange(Xr.shape[1]) - (Xr.shape[1] - 1) / 2
            dsc = np.stack([Xr.mean(1), Xr.std(1), Xr[:, -1], Xr.min(1), Xr.max(1),
                            (Xr * t[None, :, None]).sum(1) / (t ** 2).sum(),
                            Xr[:, -max(1, Xr.shape[1] // 4):].mean(1) - Xr[:, :max(1, Xr.shape[1] // 4)].mean(1)], -1)
            Hc = Hc + gelu(self.desc(const(dsc)))                                 # descriptor-augmented node tokens
            if self.post is not None:
                Hc = self.post(Hc.reshape(M, 1, C, -1), St).reshape(M, C, -1)
        z = self.readout(Hc)
        if self.seq_on:
            zs = self.seq_stream(Xd)
            g = sigmoid(self.fuse(concat([z, zs], axis=-1)))
            self.last_fuse = g.data.mean(-1)
            z = g * z + (1.0 - g) * zs
        if self.film is not None:
            z = self.film(z, St)
        else:
            z = gelu(self.sproj(concat([z, St], axis=-1)))
        return z

    def __call__(self, b, train=True):
        X, S = b["X"], b["S"]
        B, N, T, C = X.shape
        self._train = train
        z = self.encode(X.reshape(B * N, T, C), S.reshape(B * N, -1))
        d = z.shape[-1]
        if self.peer is not None:
            zb = z.reshape(B, N, d)
            zp = self.peer(zb, b["pos"])
            dev = zb - zb.mean(axis=1, keepdims=True)
            h = concat([zp, dev], axis=-1).reshape(B * N, 2 * d)
        else:
            h = z
        if self.ctx_skip:
            h = concat([h, const(S.reshape(B * N, -1))], axis=-1)
        return self.heads(h, float(self.cfg.get("dropout", 0.1)), self.rng, train)


# =====================================================================================
#                                    deep baselines
# =====================================================================================
class _Base(Module):
    def __init__(self, P, d, cfg, seed):
        self.rng = np.random.default_rng(seed); self.cfg = cfg
        self.sproj = Linear(d + P, d, self.rng)
        self.heads = (CIMHeads if cfg.get("cim_head", False) else Heads)(d, d, self.rng)

    def __call__(self, b, train=True):
        X, S = b["X"], b["S"]
        B, N, T, C = X.shape
        z = self.encode(X.reshape(B * N, T, C), S.reshape(B * N, -1))
        z = gelu(self.sproj(concat([z, const(S.reshape(B * N, -1))], axis=-1)))
        return self.heads(z, float(self.cfg.get("dropout", 0.1)), self.rng, train)


class MLPNet(_Base):
    name = "MLP"

    def __init__(self, C, T, P, A_prior, cfg, seed=0):
        d = int(cfg.get("d", 32)); super().__init__(P, d, cfg, seed)
        self.l1 = Linear(6 * C, 2 * d, self.rng); self.l2 = Linear(2 * d, d, self.rng)

    def encode(self, X, S):
        t = np.arange(X.shape[1]) - (X.shape[1] - 1) / 2
        f = np.concatenate([X.mean(1), X.std(1), X[:, -1], X.min(1), X.max(1),
                            (X * t[None, :, None]).sum(1) / (t ** 2).sum()], -1)
        return gelu(self.l2(gelu(self.l1(const(f)))))


class LSTMNet(_Base):
    name = "LSTM"

    def __init__(self, C, T, P, A_prior, cfg, seed=0):
        d = int(cfg.get("d", 32)); super().__init__(P, d, cfg, seed)
        self.inp = Linear(C, 4 * d, self.rng); self.rec = Linear(d, 4 * d, self.rng, bias=False)
        self.d = d

    def encode(self, X, S):
        M, T, C = X.shape
        d = self.d
        xin = self.inp(const(X))                                   # [M,T,4d]
        h = const(np.zeros((M, d))); c = const(np.zeros((M, d)))
        for t in range(T):
            g = xin[:, t] + self.rec(h)
            i, f, o, u = sigmoid(g[:, :d]), sigmoid(g[:, d:2 * d] + 1.0), sigmoid(g[:, 2 * d:3 * d]), tanh(g[:, 3 * d:])
            c = f * c + i * u
            h = o * tanh(c)
        return h


class TCNNet(_Base):
    name = "TCN"

    def __init__(self, C, T, P, A_prior, cfg, seed=0):
        d = int(cfg.get("d", 32)); super().__init__(P, d, cfg, seed)
        self.inp = Linear(C, d, self.rng)
        self.layers = [GatedTCN(d, dl, self.rng, k=2) for dl in (1, 2, 4, 8)]

    def encode(self, X, S):
        H = self.inp(const(X))
        for l in self.layers:
            H = l(H)
        return H[:, -1] + H.mean(axis=1)


class TransformerNet(_Base):
    name = "Transformer"

    def __init__(self, C, T, P, A_prior, cfg, seed=0):
        d = int(cfg.get("d", 32)); super().__init__(P, d, cfg, seed)
        self.inp = Linear(C, d, self.rng); self.pos = Param(self.rng.normal(0, 0.1, (T, d)))
        self.L = [(Linear(d, 3 * d, self.rng), Linear(d, d, self.rng), LayerNorm(d),
                   Linear(d, 2 * d, self.rng), Linear(2 * d, d, self.rng), LayerNorm(d)) for _ in range(2)]
        self.h = 2

    def encode(self, X, S):
        M, T, C = X.shape
        P0 = self.pos.shape[0]
        H = self.inp(const(X)) + (self.pos if T == P0 else self.pos[P0 - T:])
        d = H.shape[-1]; h, dh = self.h, d // self.h
        for qkv, o, ln1, f1, f2, ln2 in self.L:
            u = qkv(H)
            sp = lambda t: t.reshape(M, T, h, dh).transpose(0, 2, 1, 3)
            q, k, v = sp(u[..., :d]), sp(u[..., d:2 * d]), sp(u[..., 2 * d:])
            a = softmax(matmul(q, swap_last(k)) * (1 / np.sqrt(dh)), axis=-1)
            H = ln1(H + o(matmul(a, v).transpose(0, 2, 1, 3).reshape(M, T, d)))
            H = ln2(H + f2(gelu(f1(H))))
        return H.mean(axis=1) + H[:, -1]


class _GraphBase(_Base):
    """channel-as-node spatio-temporal graph baselines sharing SPRINT's tokeniser."""

    def __init__(self, C, T, P, A_prior, cfg, seed, dils, use, gate, recency_pool=False):
        d = int(cfg.get("d", 32)); super().__init__(P, d, cfg, seed)
        self.patch = p = int(cfg.get("patch", 4)); self.Tp = T // p
        self.Wc = Param(self.rng.normal(0, 1 / np.sqrt(p), (C, p, d)))
        self.bc = Param(self.rng.normal(0, 0.1, (C, d)))
        self.blocks = [([GatedTCN(d, dl, self.rng) for dl in dils], TriGraph(C, d, P, self.rng, A_prior, use=use, gate=gate))
                       for _ in range(2)]
        self.pool = RecencyPool(d, self.rng, recency=recency_pool)

    def encode(self, X, S):
        M, T, C = X.shape
        p = self.patch
        Tp = max(1, T // p)
        X = X[:, T - Tp * p:]
        Xp = X.reshape(M, Tp, p, C).transpose(0, 1, 3, 2).reshape(M, Tp, C, 1, p)
        H = matmul(const(Xp), self.Wc).reshape(M, Tp, C, -1) + self.bc
        St = const(S)
        for tcs, g in self.blocks:
            for tc in tcs:
                H = tc(H)
            H = g(H, St)
        return self.pool(H).mean(axis=1)


class STGCN(_GraphBase):
    name = "STGCN"

    def __init__(self, C, T, P, A_prior, cfg, seed=0):
        super().__init__(C, T, P, A_prior, cfg, seed, dils=(1,), use=(1, 0, 0), gate=False)


class GraphWaveNet(_GraphBase):
    name = "GraphWaveNet"

    def __init__(self, C, T, P, A_prior, cfg, seed=0):
        super().__init__(C, T, P, A_prior, cfg, seed, dils=(1, 2), use=(1, 1, 0), gate=False)


class ASTGAT(_GraphBase):
    name = "ASTGCN"

    def __init__(self, C, T, P, A_prior, cfg, seed=0):
        super().__init__(C, T, P, A_prior, cfg, seed, dils=(1,), use=(0, 0, 1), gate=False, recency_pool=True)


DEEP = dict(MLP=MLPNet, LSTM=LSTMNet, TCN=TCNNet, Transformer=TransformerNet, STGCN=STGCN,
            GraphWaveNet=GraphWaveNet, ASTGCN=ASTGAT, SPRINT=SPRINT)
