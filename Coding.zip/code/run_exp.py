"""run_exp.py -- one training/evaluation run (main / cold-start / leave-one-sport-out / ablation)."""
import numpy as np, json, os, sys, time, argparse
import autograd as ag
ag.set_dtype(np.float32)
from data import Dataset
from models import DEEP
import train as T

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results", "runs")
os.makedirs(OUT, exist_ok=True)
EVAL_KEYS = ["F1", "Acc", "R2", "MAE", "V", "NPV", "OptRate", "PEHE", "Regret"]


def robustness(model, D, idx, seed=0):
    rng = np.random.default_rng(100 + seed)
    X = D.X[idx]
    res = {}
    for p in (0.1, 0.2, 0.3, 0.4):                       # random whole-channel sensor drop-out (-> train mean)
        Xp = X.copy()
        drop = rng.random(X.shape[:2] + (1, X.shape[3])) < p
        Xp = np.where(drop, 0.0, Xp)
        m = T.metrics(D, idx, T.predict(model, D, idx, X_override=Xp))
        res[f"drop{p}"] = {k: m[k] for k in EVAL_KEYS}
    for s in (0.1, 0.25, 0.5, 0.75):                     # additive Gaussian sensor noise (z-units)
        Xp = X + rng.normal(0, s, X.shape)
        m = T.metrics(D, idx, T.predict(model, D, idx, X_override=Xp))
        res[f"noise{s}"] = {k: m[k] for k in EVAL_KEYS}
    for tl in (4, 8, 12, 16):                            # anytime inference with only the last tl epochs
        Xp = X[:, :, -tl:]
        m = T.metrics(D, idx, T.predict(model, D, idx, X_override=Xp))
        res[f"len{tl}"] = {k: m[k] for k in EVAL_KEYS}
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="SPRINT"); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--cfg", default="{}"); ap.add_argument("--tag", default="main")
    ap.add_argument("--setting", default="main"); ap.add_argument("--epochs", type=int, default=12)
    ap.add_argument("--patience", type=int, default=4); ap.add_argument("--robust", type=int, default=0)
    ap.add_argument("--save", type=int, default=0)
    A = ap.parse_args()
    cfg = dict(d=32, L=2, heads=2, k_peer=4, lr=3e-3, dropout=0.1, lam_r=0.5, lam_q=1.0, lam_p=0.3)
    cfg.update(json.loads(A.cfg))
    D = Dataset()
    tr, va, te = D.split["train"], D.split["val"], D.split["test"]
    loss_mask, sel = None, None
    if A.setting == "coldstart":
        held = (D.aid % 4 == 0)                          # 24 unseen athletes (one quarter of every squad)
        loss_mask = ~held
        mem = slice(D.P - 10, D.P)                       # reset their longitudinal memory (no history)
        D.Sx[held, mem] = 0.0; D.Sx[held, D.P - 6:D.P - 2] = 0.25
        sel = held[te]
    elif A.setting.startswith("loso:"):
        sp = A.setting.split(":")[1]
        tr = tr[D.sport[tr] != sp]; va = va[D.sport[va] != sp]; te = te[D.sport[te] == sp]
    model = DEEP[A.model](D.C, D.T, D.P, D.A_prior, cfg, seed=A.seed)
    t0 = time.time()
    hist = T.fit(model, D, cfg, epochs=A.epochs, train_idx=tr, val_idx=va, seed=A.seed, patience=A.patience,
                 loss_mask=loss_mask)
    ttime = time.time() - t0
    out = T.predict(model, D, te)
    m = T.metrics(D, te, out, sel=sel)
    m_nosafe = T.metrics(D, te, out, safety=False, sel=sel)
    lat = T.latency(model, D)
    rec = dict(model=A.model, seed=A.seed, tag=A.tag, setting=A.setting, cfg=cfg, test=m,
               test_nosafety={k: m_nosafe[k] for k in ("V", "NPV", "OptRate", "SafetyViol", "Regret")},
               n_params=model.n_params(), latency_ms=lat[0], latency_p95_ms=lat[1], train_time_s=ttime,
               epochs_run=len(hist), hist=hist)
    if A.robust:
        rec["robust"] = robustness(model, D, te, A.seed)
    name = f"{A.tag}_{A.model}_s{A.seed}"
    if A.save:
        np.savez_compressed(f"{OUT}/pred_{name}.npz", prob=out["prob"], pri=out["pri"], mu=out["mu"], prop=out["prop"],
                            emb=out["emb"][:4000], idx=te)
        np.savez_compressed(f"{OUT}/weights_{name}.npz", *model.state_dict())
        if A.model == "SPRINT":
            interp = interpret(model, D, te)
            np.savez_compressed(f"{OUT}/interp_{name}.npz", **interp)
    json.dump(rec, open(f"{OUT}/{name}.json", "w"), indent=1)
    print(name, {k: round(m[k], 4) for k in EVAL_KEYS + ["J", "J_obs"]}, "params", model.n_params(),
          "lat", round(lat[0], 3), "time", round(ttime), flush=True)


def interpret(model, D, idx, bs=8):
    """collect channel read-out attention, adjacency gates, mixed adjacency and scale attention."""
    ch, gates, adj, alpha, peer = [], [], [], [], []
    with ag.no_grad():
        for i in range(0, len(idx), bs):
            b = D.batch(idx[i:i + bs]); model(b, train=False)
            ch.append(model.readout.last)
            tb, gb = model.blocks[-1]
            if gb is not None and gb.last_gate is not None:
                gates.append(gb.last_gate)
            if gb is not None:
                A = gb.last_A
                adj.append(A.reshape(-1, A.shape[-2], A.shape[-1]).mean(0, keepdims=True).repeat(len(b["y"].ravel()), 0)
                           if A.shape[0] == 1 else A[:, 0])
            if tb.last_alpha is not None:
                alpha.append(tb.last_alpha)
            if model.peer is not None:
                peer.append(model.peer.last_att.mean(1))
    r = dict(channel_att=np.concatenate(ch))
    if gates: r["gates"] = np.concatenate(gates)
    if adj: r["adj"] = np.concatenate(adj)
    if alpha: r["scale_alpha"] = np.concatenate(alpha)
    if peer: r["peer_att"] = np.concatenate(peer)
    if model.blocks[-1][1] is not None and model.blocks[-1][1].use[1]:
        E1, E2 = model.blocks[-1][1].E1.data, model.blocks[-1][1].E2.data
        z = np.maximum(E1 @ E2.T, 0); z = np.exp(z - z.max(1, keepdims=True)); r["A_adaptive"] = z / z.sum(1, keepdims=True)
    return r


if __name__ == "__main__":
    main()
