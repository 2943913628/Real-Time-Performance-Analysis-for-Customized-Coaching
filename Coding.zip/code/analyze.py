"""analyze.py -- aggregates all runs into tables (CSV/XLSX), statistical tests and result figures."""
import numpy as np, pandas as pd, json, glob, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon, rankdata, friedmanchisquare, binomtest
from data import Dataset, CH

R = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
F = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figures")
os.makedirs(F, exist_ok=True); os.makedirs(f"{R}/tables", exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#52514e", "axes.labelcolor": "#0b0b0b", "xtick.color": "#52514e",
                     "ytick.color": "#52514e", "axes.grid": True, "grid.color": "#e6e5e0", "grid.linewidth": 0.6})
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET, RED = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"
GRAY, LGRAY = "#8a8985", "#c9c8c2"
STATES = ["Optimal", "Under-stim.", "Metabolic fat.", "NM strain"]
INTERV = ["Maintain", "Intensify", "Load mod.", "Tech. cueing", "Active rec."]
KEYS = ["Acc", "F1", "wF1", "Kappa", "MCC", "AUC", "MAE", "RMSE", "R2", "V", "Regret", "OptRate", "PEHE", "NPV", "SafetyViol", "J"]


def load_runs():
    rows = []
    for f in glob.glob(f"{R}/runs/*.json"):
        if os.path.basename(f).startswith("classical"):
            continue
        j = json.load(open(f))
        r = dict(tag=j["tag"], model=j["model"], seed=j["seed"], setting=j["setting"], params=j["n_params"],
                 lat=j["latency_ms"], lat95=j["latency_p95_ms"], ttime=j["train_time_s"], epochs=j["epochs_run"])
        r.update(j["test"])
        r.update({f"ns_{k}": v for k, v in j.get("test_nosafety", {}).items()})
        rows.append(r)
    return pd.DataFrame(rows)


def name_of(r):
    if r.tag == "main":
        return r.model
    if r.tag in ("TARNet", "DragonNet"):
        return r.tag
    return r.tag


def ms(x, d=3):
    return f"{np.mean(x):.{d}f} ± {np.std(x):.{d}f}" if len(x) > 1 else f"{np.mean(x):.{d}f}"


def main_table(df, cls):
    order = ["LR", "SVM", "RF", "HGB", "MLP", "TARNet", "DragonNet", "LSTM", "TCN", "Transformer", "STGCN", "GraphWaveNet", "ASTGCN", "SPRINT"]
    main = df[df.tag.isin(["main", "TARNet", "DragonNet"])].copy()
    main["name"] = main.apply(name_of, axis=1)
    out = []
    for n in order:
        if n in cls:
            c = cls[n]
            out.append(dict(Model=n, Family="Classical ML", **{k: f"{c[k]:.3f}" for k in KEYS if k in c},
                            Params="—", Latency=f"{c.get('latency_ms', np.nan):.3f}"))
            continue
        g = main[main.name == n]
        if len(g) == 0:
            continue
        fam = "Proposed" if n == "SPRINT" else ("Causal DL" if n in ("TARNet", "DragonNet") else
                                                ("Graph DL" if n in ("STGCN", "GraphWaveNet", "ASTGCN") else "Sequence DL"))
        out.append(dict(Model=n, Family=fam, **{k: ms(g[k].values) for k in KEYS},
                        Params=f"{int(g.params.mean()):,}", Latency=f"{g.lat.mean():.3f}"))
    T = pd.DataFrame(out)
    T.to_csv(f"{R}/tables/Table_main_comparison.csv", index=False)
    return T, main


def per_sample_tests(D, main, ref="SPRINT"):
    """paired tests on pooled seeds: McNemar (exact) on state correctness, Wilcoxon on per-sample regret."""
    te = D.split["test"]; y = D.y[te].ravel(); Q = D.Q[te].reshape(-1, 5)
    import train as T
    preds = {}
    for f in glob.glob(f"{R}/runs/pred_main_*_s*.npz") + glob.glob(f"{R}/runs/pred_TARNet_*.npz") + glob.glob(f"{R}/runs/pred_DragonNet_*.npz") + glob.glob(f"{R}/runs/pred_MLPaug_*.npz"):
        b = os.path.basename(f)[5:-4]
        parts = b.split("_")
        if parts[0] == "main":
            name, seed = parts[1], parts[-1]
        else:
            name, seed = parts[0], parts[-1]
        z = np.load(f)
        if "prob" not in z:
            continue
        pi = T.recommend(z["mu"], z["prob"]) if z["mu"].ndim == 2 else None
        preds.setdefault(name, {})[seed] = dict(correct=(z["prob"].argmax(1) == y), regret=Q.max(1) - Q[np.arange(len(pi)), pi])
    rows = []
    if ref not in preds:
        return pd.DataFrame()
    for n, P in preds.items():
        if n == ref:
            continue
        seeds = sorted(set(P) & set(preds[ref]))
        if not seeds:
            continue
        a = np.concatenate([preds[ref][s]["correct"] for s in seeds]); b = np.concatenate([P[s]["correct"] for s in seeds])
        n01, n10 = int((a & ~b).sum()), int((~a & b).sum())
        p_mc = binomtest(n01, n01 + n10, 0.5).pvalue if n01 + n10 > 0 else 1.0
        ra = np.concatenate([preds[ref][s]["regret"] for s in seeds]); rb = np.concatenate([P[s]["regret"] for s in seeds])
        d = rb - ra
        p_w = wilcoxon(d[d != 0]).pvalue if (d != 0).sum() > 10 else 1.0
        rng = np.random.default_rng(0)
        boots = [d[rng.integers(0, len(d), len(d))].mean() for _ in range(1000)]
        rows.append(dict(Baseline=n, SPRINT_better=n01, Baseline_better=n10, McNemar_p=p_mc,
                         dRegret_mean=d.mean(), dRegret_CI_low=np.percentile(boots, 2.5), dRegret_CI_high=np.percentile(boots, 97.5),
                         Wilcoxon_p=p_w))
    S = pd.DataFrame(rows).sort_values("Baseline")
    S.to_csv(f"{R}/tables/Table_significance.csv", index=False)
    return S


def bar_panel(ax, names, vals, errs, title, hi="SPRINT", fmt="{:.3f}", lo=None):
    cols = [BLUE if n == hi else (LGRAY if n in ("LR", "SVM", "RF", "HGB") else GRAY) for n in names]
    y = np.arange(len(names))
    raw = np.array(vals, dtype=float)
    if lo is not None:
        vals = np.maximum(raw, lo)
    ax.barh(y, vals, xerr=errs, color=cols, height=0.62, edgecolor="white", linewidth=1.5,
            error_kw=dict(ecolor="#3a3a38", lw=0.8, capsize=2))
    ax.set_yticks(y); ax.set_yticklabels(names); ax.invert_yaxis(); ax.set_title(title, fontsize=10, fontweight="bold", loc="left")
    ax.grid(axis="y", visible=False)
    vmin = np.nanmin(vals - np.nan_to_num(errs)) if lo is None else lo; vmax = np.nanmax(vals + np.nan_to_num(errs))
    pad = (vmax - vmin) * 0.25 + 1e-6
    ax.set_xlim(lo if lo is not None else max(0, vmin - pad), vmax + pad * 0.6)
    for i, (v, e, rv) in enumerate(zip(vals, errs, raw)):
        ax.text(v + (np.nan_to_num(e)) + pad * 0.05, i, fmt.format(rv) + (" (clipped)" if rv < v else ""), va="center", fontsize=7.5, color="#0b0b0b")


def fig_main(T, main, cls):
    names, F1m, F1s, R2m, R2s, Vm, Vs = [], [], [], [], [], [], []
    for n in T.Model:
        if n in cls:
            c = cls[n]; names.append(n); F1m.append(c["F1"]); F1s.append(0); R2m.append(c["R2"]); R2s.append(0)
            Vm.append(c["NPV"]); Vs.append(0); continue
        g = main[main.name == n]
        names.append(n); F1m.append(g.F1.mean()); F1s.append(g.F1.std(ddof=0)); R2m.append(g.R2.mean()); R2s.append(g.R2.std(ddof=0))
        Vm.append(g.NPV.mean()); Vs.append(g.NPV.std(ddof=0))
    fig, axs = plt.subplots(1, 3, figsize=(15, 5.4), sharey=True)
    bar_panel(axs[0], names, np.array(F1m), np.array(F1s), "(a) Performance-state recognition: macro-F1")
    bar_panel(axs[1], names, np.array(R2m), np.array(R2s), "(b) Readiness (PRI) estimation: R²")
    bar_panel(axs[2], names, np.array(Vm), np.array(Vs), "(c) Coaching policy: normalised value (NPV)")
    fig.tight_layout(); fig.savefig(f"{F}/Fig5_main_comparison.png", dpi=300); plt.close(fig)


def fig_hpo_bench():
    fig = plt.figure(figsize=(15, 7.6))
    gs = fig.add_gridspec(2, 4, hspace=0.42, wspace=0.32)
    ax = fig.add_subplot(gs[:, :2])
    cols = dict(RS=GRAY, PSO=ORANGE, GWO=AQUA, CLEAR_GWO=BLUE)
    lab = dict(RS="Random search", PSO="PSO", GWO="GWO", CLEAR_GWO="CLEAR-GWO (proposed)")
    for k in ["RS", "PSO", "GWO", "CLEAR_GWO"]:
        f = f"{R}/hpo_{k}.json"
        if not os.path.exists(f):
            continue
        j = json.load(open(f)); fit = [e["fitness"] for e in j["log"]]
        best = np.minimum.accumulate(fit)
        ax.step(np.arange(1, len(best) + 1), best, where="post", color=cols[k], lw=2.2 if k == "CLEAR_GWO" else 1.6, label=lab[k])
        ax.scatter(np.arange(1, len(fit) + 1), fit, s=10, color=cols[k], alpha=0.35)
    ax.set_xlabel("objective evaluations (proxy SPRINT trainings)"); ax.set_ylabel("resource-aware fitness F (lower is better)")
    ax.set_title("(a) Hyper-parameter search for SPRINT (equal budget)", loc="left", fontweight="bold")
    ax.legend(frameon=False)
    lo = []
    for k in ["RS", "PSO", "GWO", "CLEAR_GWO"]:
        f = f"{R}/hpo_{k}.json"
        if os.path.exists(f):
            lo.append(min(e["fitness"] for e in json.load(open(f))["log"]))
    if lo:
        ax.set_ylim(min(lo) - 0.01, min(lo) + 0.12)
    B = json.load(open(f"{R}/bench_optimizers.json"))
    cps = np.array(B["checkpoints"])
    fns = ["F1 Sphere", "F4 Rastrigin", "F5 Ackley", "F7 Levy"]
    bc = dict(PSO=ORANGE, DE=YELLOW, WOA=MAGENTA, GWO=AQUA, IGWO=VIOLET, CLEAR_GWO=BLUE)
    for i, fn in enumerate(fns):
        a = fig.add_subplot(gs[i // 2, 2 + i % 2])
        for k, c in bc.items():
            cv = np.array(B["res"][fn][k].get("curve_geo", B["res"][fn][k]["curve"]))
            a.plot(cps, np.maximum(cv, 1e-8), color=c, lw=2.0 if k == "CLEAR_GWO" else 1.2,
                   label=("CLEAR-GWO" if k == "CLEAR_GWO" else k))
        a.set_yscale("log"); a.set_title(f"({'bcde'[i]}) {fn} (D = 30)", loc="left", fontsize=9.5, fontweight="bold")
        a.set_xlabel("function evaluations"); a.set_ylabel("best-so-far (geometric mean, 10 runs)")
        if i == 0:
            a.legend(frameon=False, fontsize=7, ncol=2)
    fig.savefig(f"{F}/Fig4_optimizer_convergence.png", dpi=300, bbox_inches="tight"); plt.close(fig)


def bench_table():
    """geometric-mean (log10) aggregation is used because best-so-far values are heavy-tailed across runs."""
    B = json.load(open(f"{R}/bench_optimizers.json"))["res"]
    algs = ["RS", "PSO", "DE", "WOA", "GWO", "IGWO", "CLEAR_GWO", "CLEAR w/o chaos", "CLEAR w/o Levy", "CLEAR w/o elite",
            "CLEAR w/o DLH", "CLEAR w/o weights", "CLEAR linear a"]
    lg = lambda f, a: np.log10(np.array(B[f][a]["best"]) + 1e-12)
    rows = []
    main7 = ["RS", "PSO", "DE", "WOA", "GWO", "IGWO", "CLEAR_GWO"]
    M7 = np.array([[lg(f, a).mean() for a in main7] for f in B])
    R7 = np.array([rankdata(r) for r in M7])
    for i, f in enumerate(B):
        rows.append({"Function": f, **{a: f"{np.median(B[f][a]['best']):.2e} ({lg(f, a).mean():.2f})" for a in algs}})
    MA = np.array([[lg(f, a).mean() for a in algs] for f in B])
    RA = np.array([rankdata(r) for r in MA])
    rows.append({"Function": "Mean rank (all 13)", **{a: f"{RA[:, j].mean():.2f}" for j, a in enumerate(algs)}})
    stat, p = friedmanchisquare(*M7.T)
    pw = {}
    for a in main7[:-1]:
        x = np.concatenate([lg(f, "CLEAR_GWO") for f in B]); y = np.concatenate([lg(f, a) for f in B])
        pw[a] = dict(wins=int((x < y).sum()), losses=int((x > y).sum()), p=float(wilcoxon(x - y).pvalue))
    T = pd.DataFrame(rows)
    T.to_csv(f"{R}/tables/Table_benchmark_optimizers.csv", index=False)
    out = dict(friedman_stat=float(stat), friedman_p=float(p), pairwise=pw,
               mean_rank_main=dict(zip(main7, R7.mean(0).tolist())),
               best_count={a: int((R7[:, j] == 1).sum()) for j, a in enumerate(main7)},
               logmeans={f: {a: float(lg(f, a).mean()) for a in algs} for f in B})
    json.dump(out, open(f"{R}/tables/benchmark_stats.json", "w"), indent=1)
    return T, pw, stat, p


def fig_data(D):
    fig = plt.figure(figsize=(15, 7.8))
    gs = fig.add_gridspec(2, 3, hspace=0.45, wspace=0.3)
    # (a) example session of one athlete: 4 channels over 6 windows
    snaps = np.where((D.squad == 2) & (D.session == 12))[0]
    j = 3
    X = D.raw_X[snaps][:, j]                                  # [6,T,C]
    t = np.arange(X.shape[0] * X.shape[1]) * 15 / 60
    chs = [(0, "HR\n(bpm)", RED), (4, "Speed\n(m/s)", BLUE), (11, "Asym.\n(%)", VIOLET), (7, "SmO₂\n(%)", AQUA)]
    sub = gs[0, :2].subgridspec(4, 1, hspace=0.15)
    ys = D.y[snaps, j]
    for k, (c, lab, col) in enumerate(chs):
        a = fig.add_subplot(sub[k])
        a.plot(t, X[:, :, c].ravel(), color=col, lw=1.3)
        for w in range(1, X.shape[0]):
            a.axvline(w * 5, color=LGRAY, lw=0.8)
        a.set_ylabel(lab, fontsize=7.5); a.tick_params(labelsize=7)
        if k == 0:
            for w in range(X.shape[0]):
                a.text(w * 5 + 2.5, a.get_ylim()[1], STATES[ys[w]], ha="center", va="bottom", fontsize=7, color="#3a3a38")
            a.set_title("(a) One athlete, one session: 6 five-minute windows (labels above)", loc="left", fontweight="bold", fontsize=9.5, pad=14)
        if k < 3:
            a.set_xticklabels([])
        else:
            a.set_xlabel("session time (min)")
    # (b) class distribution per sport
    ax = fig.add_subplot(gs[0, 2])
    sports = D.meta["sports"]; cols = [BLUE, ORANGE, AQUA, VIOLET]
    bottom = np.zeros(len(sports))
    for c in range(4):
        v = np.array([(D.y[D.sport == s_] == c).mean() for s_ in sports])
        ax.bar(sports, v, bottom=bottom, color=cols[c], edgecolor="white", linewidth=1.5, label=STATES[c], width=0.65)
        bottom += v
    ax.set_title("(b) Performance-state prevalence", loc="left", fontweight="bold", fontsize=9.5); ax.set_ylabel("share of athlete-windows")
    ax.legend(frameon=False, fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.12), ncol=2); ax.tick_params(axis="x", labelsize=7.5)
    ax.grid(axis="x", visible=False)
    # (c) oracle-best intervention by state
    ax = fig.add_subplot(gs[1, 0])
    best = D.Q.reshape(-1, 5).argmax(1); yy = D.y.ravel()
    M = np.array([[np.mean(best[yy == s_] == k) for k in range(5)] for s_ in range(4)])
    im = ax.imshow(M, cmap="Blues", vmin=0, vmax=0.6, aspect="auto")
    for i in range(4):
        for k in range(5):
            ax.text(k, i, f"{M[i, k]:.2f}", ha="center", va="center", fontsize=7.5, color="white" if M[i, k] > 0.35 else "#0b0b0b")
    ax.set_xticks(range(5)); ax.set_xticklabels(INTERV, rotation=30, ha="right", fontsize=7.5); ax.set_yticks(range(4)); ax.set_yticklabels(STATES, fontsize=7.5)
    ax.set_title("(c) Oracle-best intervention | state", loc="left", fontweight="bold", fontsize=9.5); ax.grid(False)
    # (d) logged coach policy vs oracle
    ax = fig.add_subplot(gs[1, 1])
    a_ = D.a.ravel()
    v1 = np.bincount(a_, minlength=5) / len(a_); v2 = np.bincount(best, minlength=5) / len(best)
    x = np.arange(5)
    ax.bar(x - 0.18, v1, 0.34, color=GRAY, label="logged coach decisions", edgecolor="white")
    ax.bar(x + 0.18, v2, 0.34, color=BLUE, label="oracle-best intervention", edgecolor="white")
    ax.set_xticks(x); ax.set_xticklabels(INTERV, rotation=30, ha="right", fontsize=7.5); ax.legend(frameon=False, fontsize=7.5)
    ax.set_title("(d) Intervention mix", loc="left", fontweight="bold", fontsize=9.5); ax.grid(axis="x", visible=False)
    # (e) PRI distribution by state
    ax = fig.add_subplot(gs[1, 2])
    data = [D.pri.ravel()[yy == s_] for s_ in range(4)]
    bp = ax.boxplot(data, patch_artist=True, widths=0.55, showfliers=False)
    for p_, c in zip(bp["boxes"], cols):
        p_.set_facecolor(c); p_.set_alpha(0.75); p_.set_edgecolor("#3a3a38")
    for med in bp["medians"]:
        med.set_color("#0b0b0b")
    ax.set_xticks(range(1, 5)); ax.set_xticklabels(STATES, fontsize=7.5, rotation=15); ax.set_ylabel("PRI (0–100)")
    ax.set_title("(e) Readiness index by state", loc="left", fontweight="bold", fontsize=9.5); ax.grid(axis="x", visible=False)
    fig.savefig(f"{F}/Fig3_dataset_overview.png", dpi=300, bbox_inches="tight"); plt.close(fig)


def fig_confusion_policy(D, cls):
    import train as T
    from sklearn.metrics import confusion_matrix, f1_score
    te = D.split["test"]; y = D.y[te].ravel(); Q = D.Q[te].reshape(-1, 5)
    fs = sorted(glob.glob(f"{R}/runs/pred_main_SPRINT_s*.npz"))
    if not fs:
        return
    z = np.load(fs[0]); prob, mu = z["prob"], z["mu"]
    pi = T.recommend(mu, prob)
    fig = plt.figure(figsize=(15, 4.9))
    gs = fig.add_gridspec(1, 3, wspace=0.38, width_ratios=[1, 1.15, 1.1])
    ax = fig.add_subplot(gs[0])
    C = confusion_matrix(y, prob.argmax(1), normalize="true")
    ax.imshow(C, cmap="Blues", vmin=0, vmax=1)
    for i in range(4):
        for k in range(4):
            ax.text(k, i, f"{C[i, k]:.2f}", ha="center", va="center", fontsize=8.5, color="white" if C[i, k] > 0.5 else "#0b0b0b")
    ax.set_xticks(range(4)); ax.set_xticklabels(STATES, rotation=25, ha="right", fontsize=8); ax.set_yticks(range(4)); ax.set_yticklabels(STATES, fontsize=8)
    ax.set_xlabel("predicted"); ax.set_ylabel("true"); ax.grid(False)
    ax.set_title("(a) SPRINT confusion matrix (test)", loc="left", fontweight="bold", fontsize=9.5)
    # (b) policy values
    ax = fig.add_subplot(gs[1])
    pol = {"Random": Q.mean(), "Always maintain": Q[:, 0].mean(), "Logged coach": Q[np.arange(len(y)), D.a[te].ravel()].mean(),
           "State rule (true state)": Q[np.arange(len(y)), np.array([0, 1, 2, 4])[y]].mean()}
    for n in ["HGB", "RF"]:
        if n in cls:
            pol[n] = cls[n]["V"]
    for n in ["MLP", "TCN", "GraphWaveNet"]:
        g = [json.load(open(f))["test"]["V"] for f in glob.glob(f"{R}/runs/main_{n}_s*.json")]
        if g:
            pol[n] = np.mean(g)
    g = [json.load(open(f))["test"]["V"] for f in glob.glob(f"{R}/runs/main_SPRINT_s*.json")]
    pol["SPRINT"] = np.mean(g); pol["Oracle"] = Q.max(1).mean()
    names = list(pol); vals = np.array([pol[n] for n in names])
    cols = [BLUE if n == "SPRINT" else (GREEN if n == "Oracle" else GRAY) for n in names]
    ax.barh(range(len(names)), vals, color=cols, height=0.62, edgecolor="white")
    ax.set_yticks(range(len(names))); ax.set_yticklabels(names, fontsize=8); ax.invert_yaxis()
    for i, v in enumerate(vals):
        ax.text(v + 0.15, i, f"{v:.2f}", va="center", fontsize=7.5)
    ax.set_xlabel("expected training effectiveness of next window (true Q)"); ax.grid(axis="y", visible=False)
    ax.set_xlim(min(vals) - 1, max(vals) + 1.6)
    ax.set_title("(b) Value of coaching policies (test)", loc="left", fontweight="bold", fontsize=9.5)
    # (c) recommendation | state
    ax = fig.add_subplot(gs[2])
    M = np.array([[np.mean(pi[y == s_] == k) for k in range(5)] for s_ in range(4)])
    ax.imshow(M, cmap="Blues", vmin=0, vmax=0.8, aspect="auto")
    for i in range(4):
        for k in range(5):
            ax.text(k, i, f"{M[i, k]:.2f}", ha="center", va="center", fontsize=8, color="white" if M[i, k] > 0.45 else "#0b0b0b")
    ax.set_xticks(range(5)); ax.set_xticklabels(INTERV, rotation=30, ha="right", fontsize=8); ax.set_yticks(range(4)); ax.set_yticklabels(STATES, fontsize=8)
    ax.grid(False); ax.set_title("(c) SPRINT recommendation | true state", loc="left", fontweight="bold", fontsize=9.5)
    fig.savefig(f"{F}/Fig6_confusion_policy.png", dpi=300, bbox_inches="tight"); plt.close(fig)
    return f1_score(y, prob.argmax(1), average=None)


def robust_table_fig(cls):
    models = ["SPRINT", "MLP", "TCN", "Transformer", "GraphWaveNet", "LSTM", "STGCN", "ASTGCN", "MLPaug"]
    R_ = {}
    for m in models:
        f = f"{R}/runs/main_{m}_s0.json" if m != "MLPaug" else f"{R}/runs/MLPaug_MLP_s0.json"
        if os.path.exists(f):
            j = json.load(open(f))
            if "robust" in j:
                R_[m] = dict(clean=j["test"], **j["robust"])
    for m in ["HGB"]:
        if m in cls and "robust" in cls[m]:
            R_[m] = dict(clean=cls[m], **cls[m]["robust"])
    show = [m for m in ["SPRINT", "HGB", "MLP", "TCN", "GraphWaveNet"] if m in R_]
    cols = dict(SPRINT=BLUE, HGB=ORANGE, MLP=AQUA, TCN=YELLOW, GraphWaveNet=VIOLET)
    fig, axs = plt.subplots(1, 3, figsize=(15, 4.4))
    specs = [("drop", [0.0, 0.1, 0.2, 0.3, 0.4], "sensor drop-out rate (whole channels)"),
             ("noise", [0.0, 0.1, 0.25, 0.5, 0.75], "additive sensor noise σ (z-units)"),
             ("len", [4, 8, 12, 16, 20], "observed epochs in window (15 s each)")]
    rows = []
    for ax, (key, xs, xl) in zip(axs, specs):
        for m in show:
            v = []
            for x in xs:
                if (key != "len" and x == 0.0) or (key == "len" and x == 20):
                    v.append(R_[m]["clean"]["F1"])
                else:
                    v.append(R_[m][f"{key}{x}"]["F1"])
            ax.plot(xs, v, "-o", color=cols[m], lw=2.2 if m == "SPRINT" else 1.4, ms=5, label=m)
        ax.set_xlabel(xl); ax.set_ylabel("macro-F1")
        ax.set_title({"drop": "(a) Sensor drop-out", "noise": "(b) Sensor noise", "len": "(c) Anytime (short windows)"}[key],
                     loc="left", fontweight="bold", fontsize=9.5)
    axs[0].legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig(f"{F}/Fig7_robustness.png", dpi=300); plt.close(fig)
    for m in R_:
        r = {"Model": m, "Clean F1": R_[m]["clean"]["F1"], "Clean NPV": R_[m]["clean"]["NPV"]}
        Js = [0.5 * R_[m][k]["F1"] + 0.25 * max(R_[m][k]["R2"], 0) + 0.25 * R_[m][k]["NPV"] for k in R_[m]]
        r["Mean J (13 cond.)"] = float(np.mean(Js))
        for k in ["drop0.2", "drop0.4", "noise0.5", "len8", "len4"]:
            if k in R_[m]:
                r[f"{k} F1"] = R_[m][k]["F1"]; r[f"{k} NPV"] = R_[m][k]["NPV"]
        rows.append(r)
    T = pd.DataFrame(rows); T.to_csv(f"{R}/tables/Table_robustness.csv", index=False)
    return T


def fig_interp(D):
    fs = sorted(glob.glob(f"{R}/runs/interp_main_SPRINT_s0.npz"))
    if not fs:
        return
    z = np.load(fs[0]); te = D.split["test"]; y = D.y[te].ravel(); sp = np.repeat(D.sport[te], D.N)
    ch = z["channel_att"]
    fig = plt.figure(figsize=(15, 9))
    gs = fig.add_gridspec(2, 3, hspace=0.42, wspace=0.42)
    ax = fig.add_subplot(gs[0, :2])
    M = np.array([ch[y == s_].mean(0) for s_ in range(4)])
    Mr = M / M.mean(0, keepdims=True)
    im = ax.imshow(Mr, cmap="RdBu_r", vmin=0.8, vmax=1.2, aspect="auto")
    for i in range(4):
        for k in range(12):
            ax.text(k, i, f"{M[i, k]:.3f}", ha="center", va="center", fontsize=7)
    ax.set_xticks(range(12)); ax.set_xticklabels([c.split("_")[0] for c in CH], rotation=35, ha="right", fontsize=8)
    ax.set_yticks(range(4)); ax.set_yticklabels(STATES, fontsize=8); ax.grid(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.025); cb.set_label("relative to channel mean", fontsize=7.5)
    ax.set_title("(a) Sensor read-out attention β_c by performance state (cell = mean weight)", loc="left", fontweight="bold", fontsize=9.5)
    ax = fig.add_subplot(gs[0, 2])
    if "gates" in z:
        g = z["gates"]
        sports = D.meta["sports"]
        G = np.array([g[sp == s_].mean(0) for s_ in sports])
        lab = ["prior", "adaptive", "dynamic"][:G.shape[1]]
        bottom = np.zeros(len(sports))
        for k, c in enumerate([GRAY, AQUA, BLUE][:G.shape[1]]):
            ax.bar(sports, G[:, k], bottom=bottom, color=c, edgecolor="white", linewidth=1.5, label=lab[k], width=0.6)
            bottom += G[:, k]
        ax.legend(frameon=False, fontsize=7.5, loc="lower right"); ax.set_ylabel("mean gate weight"); ax.tick_params(axis="x", labelsize=7.5)
        ax.grid(axis="x", visible=False)
    ax.set_title("(b) TAG adjacency gates by sport", loc="left", fontweight="bold", fontsize=9.5)
    short = [c.split("_")[0] for c in CH]
    for k, (key, title) in enumerate([("A_adaptive", "(c) Learned adaptive adjacency A_adp"), ("adj", "(d) Mixed sensor graph A (test mean)")]):
        ax = fig.add_subplot(gs[1, k])
        if key in z:
            A = z[key] if z[key].ndim == 2 else z[key].mean(0)
            ax.imshow(A, cmap="Blues", vmin=0, vmax=np.percentile(A, 98))
            ax.set_xticks(range(12)); ax.set_xticklabels(short, rotation=60, fontsize=7); ax.set_yticks(range(12)); ax.set_yticklabels(short, fontsize=7)
            ax.grid(False)
        ax.set_title(title, loc="left", fontweight="bold", fontsize=9.5)
    ax = fig.add_subplot(gs[1, 2])
    if "peer_att" in z:
        P = z["peer_att"][5]
        ax.imshow(P, cmap="Blues", vmin=0, vmax=np.percentile(P, 98))
        pos = D.pos[te][5]
        ax.set_xticks(range(12)); ax.set_xticklabels([f"A{i}\nP{pos[i]}" for i in range(12)], fontsize=6)
        ax.set_yticks(range(12)); ax.set_yticklabels([f"A{i}" for i in range(12)], fontsize=6.5); ax.grid(False)
    ax.set_title("(e) Peer attention in one squad window", loc="left", fontweight="bold", fontsize=9.5)
    fig.savefig(f"{F}/Fig8_interpretability.png", dpi=300, bbox_inches="tight"); plt.close(fig)
    return M


if __name__ == "__main__":
    pass
